/* global React, Icon, LyrixaData */
const { useState: useVS } = React;
const { MASTER_PEAKS, VOCALS_PEAKS, MAIN_CLIPS, BACKING_CLIPS } = LyrixaData;

// ============================================================
// Static mini-waveform (no scroll, no peaks slicing)
// ============================================================

function MiniWaveform({ peaks, color, opacity = 0.85, width, height }) {
  const w = 360;
  const h = 100;
  return (
    <svg
      preserveAspectRatio="none"
      viewBox={`0 0 ${w} ${h}`}
      style={{ position: "absolute", inset: "10% 0", width: "100%", height: "80%", color }}
    >
      {peaks.slice(0, w).map((v, i) => (
        <rect key={i} x={i} y={50 - v * 40} width={0.8} height={v * 80} fill="currentColor" opacity={opacity} />
      ))}
    </svg>
  );
}

// ============================================================
// Mini editor slice — used for theme variations
// ============================================================

function EditorSlice({ themeClass, label, accentName }) {
  return (
    <div className={`editor-slice ${themeClass}`} style={{ position: "relative" }}>
      <div className="dir-caption">
        <span className="dot" />
        {label} · accent {accentName}
      </div>

      {/* Transport */}
      <div className="transport">
        <div className="brand">
          <div className="brand-mark">L</div>
          Lyrixa
        </div>
        <div className="tr-divider" />
        <button className="song-chip">
          <Icon name="file-music" size={12} style={{ color: "var(--c-master)", flexShrink: 0 }} />
          <span className="title">Velvet Hours — Pale Wolves</span>
        </button>
        <button className="tr-btn" style={{ background: "var(--bg-2)", border: "1px solid var(--border)" }}>
          <Icon name="scan" size={12} />
          Isolate
        </button>
        <div className="tr-divider" />
        <div className="playback-cluster" style={{ padding: 0 }}>
          <button className="play-btn"><Icon name="play" size={12} /></button>
          <span className="time-readout">0:50.94 <span className="total">/ 3:33</span></span>
        </div>
        <div className="tr-divider" />
        <button className="tr-btn primary">
          <Icon name="wand" size={12} />
          Auto-sync
        </button>
        <div className="transport-spacer" />
        <div className="stem-indicator"><span className="dot" />Stem</div>
        <div className="save-status"><span className="dot" />Saved</div>
      </div>

      {/* Sidebar */}
      <aside className="sidebar">
        <div className="sidebar-header">
          <div className="label-eyebrow">Layers</div>
        </div>
        <div className="sidebar-body">
          <div className="section-title">Tracks</div>
          {[
            { name: "Main Lyrics", color: "var(--c-main)", count: 18, selected: true },
            { name: "Backing", color: "var(--c-backing)", count: 7 },
            { name: "FX / Adlibs", color: "var(--c-fx)", count: 5 },
          ].map(l => (
            <div key={l.name} className={`layer-row ${l.selected ? "selected" : ""}`}>
              <span className="swatch" style={{ background: l.color }} />
              <div className="lname">{l.name}</div>
              <span className="lmeta">{l.count}</span>
            </div>
          ))}
        </div>
      </aside>

      {/* Stage */}
      <main className="stage">
        <div className="stage-toolbar">
          <div className="tool-group">
            <button className="tool-btn active"><Icon name="type" size={11} />Edit</button>
            <button className="tool-btn"><Icon name="scissors" size={11} />Cut</button>
          </div>
          <div className="tool-group">
            <button className="tool-btn icon-only" style={{ width: 22 }}><Icon name="minus" size={11} /></button>
            <span className="zoom-readout">60 px/s</span>
            <button className="tool-btn icon-only" style={{ width: 22 }}><Icon name="plus" size={11} /></button>
          </div>
          <div className="tool-group">
            <button className="tool-btn active"><Icon name="magnet" size={11} />Beat</button>
          </div>
        </div>

        <div className="timeline">
          <div className="ruler-pad">Time</div>
          <div className="ruler">
            {[0, 4, 8, 12, 16, 20, 24].map(s => (
              <div key={s} className="ruler-tick major" style={{ left: `${s * 24}px` }}>
                0:{String(s).padStart(2, "0")}
              </div>
            ))}
          </div>

          <div className="track-headers">
            <div className="track-header" style={{ height: 64 }}>
              <span className="accent" style={{ background: "var(--c-master)" }} />
              <div style={{ padding: "0 0 0 8px", flex: 1 }}>
                <div className="th-name" style={{ display: "flex", alignItems: "center", gap: 4 }}>
                  <Icon name="waveform" size={10} style={{ color: "var(--c-master)" }} />
                  Master
                </div>
                <div className="th-meta">Stereo</div>
              </div>
            </div>
            <div className="track-header" style={{ height: 52 }}>
              <span className="accent" style={{ background: "var(--c-vocals)" }} />
              <div style={{ padding: "0 0 0 8px", flex: 1 }}>
                <div className="th-name" style={{ display: "flex", alignItems: "center", gap: 4 }}>
                  <Icon name="mic" size={10} style={{ color: "var(--c-vocals)" }} />
                  Vocals stem
                </div>
                <div className="th-meta">36 segments</div>
              </div>
            </div>
            <div className="track-header" style={{ height: 48 }}>
              <span className="accent" style={{ background: "var(--c-main)" }} />
              <div style={{ padding: "0 0 0 8px", flex: 1 }}>
                <div className="th-name">Main Lyrics</div>
                <div className="th-meta">18 clips · Bottom</div>
              </div>
            </div>
            <div className="track-header" style={{ height: 44 }}>
              <span className="accent" style={{ background: "var(--c-backing)" }} />
              <div style={{ padding: "0 0 0 8px", flex: 1 }}>
                <div className="th-name">Backing</div>
                <div className="th-meta">7 clips · Top</div>
              </div>
            </div>
          </div>

          <div className="tracks" style={{ overflow: "hidden" }}>
            <div className="tracks-inner">
              <div className="lane master" style={{ height: 64, position: "relative" }}>
                <MiniWaveform peaks={MASTER_PEAKS} color="var(--c-master)" />
              </div>
              <div className="lane vocals" style={{ height: 52, position: "relative" }}>
                <MiniWaveform peaks={VOCALS_PEAKS} color="var(--c-vocals)" />
              </div>
              <div className="lane" style={{ height: 48, position: "relative" }}>
                {[
                  { left: 12, w: 110, t: "Awake inside the velvet hours" },
                  { left: 130, w: 100, t: "Streetlights drown" },
                  { left: 238, w: 130, t: "I traced your name on the glass", active: true },
                ].map((c, i) => (
                  <div key={i} className={`clip ${c.active ? "active selected" : ""}`}
                    style={{
                      left: c.left, width: c.w, top: 4, bottom: 4,
                      "--clip-bg": "oklch(from var(--c-main) l c h / 0.16)",
                      "--clip-border": "oklch(from var(--c-main) l c h / 0.6)",
                    }}
                  >
                    <div className="clip-text" style={{ fontSize: 10.5 }}>{c.t}</div>
                  </div>
                ))}
              </div>
              <div className="lane" style={{ height: 44, position: "relative" }}>
                {[
                  { left: 22, w: 60, t: "ooh —" },
                  { left: 240, w: 90, t: "(whisper) hush" },
                ].map((c, i) => (
                  <div key={i} className="clip"
                    style={{
                      left: c.left, width: c.w, top: 4, bottom: 4,
                      "--clip-bg": "oklch(from var(--c-backing) l c h / 0.16)",
                      "--clip-border": "oklch(from var(--c-backing) l c h / 0.5)",
                    }}
                  >
                    <div className="clip-text" style={{ fontSize: 10.5 }}>{c.t}</div>
                  </div>
                ))}
              </div>
            </div>
            <div className="playhead" style={{ left: 200 }} />
          </div>
        </div>
      </main>

      {/* Inspector */}
      <aside className="inspector">
        <div className="inspector-header">
          <div>
            <div className="inspector-title">Inspector</div>
            <div className="inspector-subject">
              <span>1 clip</span>
              <span className="ctx-pill"><span className="dot" />Clip</span>
            </div>
          </div>
        </div>
        <div className="inspector-tabs">
          {["Project", "Layer", "Clip", "Style", "FX"].map((t, i) => (
            <button key={t} className={`itab ${t === "Style" ? "active" : ""}`}>{t}</button>
          ))}
        </div>
        <div className="inspector-body">
          <div className="disclosure">
            <div className="disclosure-head">Typography <span className="chev"><Icon name="chev-down" size={10} /></span></div>
            <div className="disclosure-body">
              <div className="field">
                <div className="field-label">Font</div>
                <select className="select"><option>Geist</option></select>
              </div>
              <div className="field-row">
                <div className="field"><div className="field-label">Size</div><input className="input mono" defaultValue="2.8rem" /></div>
                <div className="field"><div className="field-label">Weight</div><select className="select"><option>800</option></select></div>
              </div>
            </div>
          </div>
          <div className="disclosure">
            <div className="disclosure-head">Fill <span className="chev"><Icon name="chev-down" size={10} /></span></div>
            <div className="disclosure-body">
              <div className="fill-tabs">
                <button className="fill-tab"><span className="preview-swatch" style={{ background: "#fff" }} /><span className="pname">Solid</span></button>
                <button className="fill-tab active"><span className="preview-swatch" style={{ background: "linear-gradient(135deg, #fff, var(--accent))" }} /><span className="pname">Gradient</span></button>
                <button className="fill-tab"><span className="preview-swatch" style={{ background: "var(--bg-3)" }} /><span className="pname">Texture</span></button>
              </div>
              <div className="field">
                <div className="field-label">Angle</div>
                <div className="slider">
                  <div className="slider-track">
                    <div className="slider-fill" style={{ width: "30%" }} />
                    <div className="slider-thumb" style={{ left: "30%" }} />
                  </div>
                  <div className="slider-value">110°</div>
                </div>
              </div>
            </div>
          </div>
          <div className="disclosure">
            <div className="disclosure-head">Glow &amp; shadow <span className="chev"><Icon name="chev-down" size={10} /></span></div>
          </div>
        </div>
      </aside>
    </div>
  );
}

// ============================================================
// Inspector pattern variations
// ============================================================

function InspectorPatternA() {
  // Current — tabs + context pill
  return (
    <div className={`inspector-pattern`}>
      <div className="inspector-header" style={{ display: "block" }}>
        <div className="inspector-title">Inspector</div>
        <div className="inspector-subject">
          <span>Quiet as a runway lamp</span>
          <span className="ctx-pill"><span className="dot" />Clip</span>
        </div>
      </div>
      <div className="inspector-tabs">
        {["Project", "Layer", "Clip", "Style", "Anim", "FX"].map(t => (
          <button key={t} className={`itab ${t === "Clip" ? "active" : ""}`}>
            {t}
            {t === "Clip" && <span className="dot-override" />}
          </button>
        ))}
      </div>
      <div className="inspector-body" style={{ flex: 1, overflow: "auto" }}>
        <PatternBodyClip />
      </div>
    </div>
  );
}

function InspectorPatternB() {
  // Breadcrumb at top — context as path
  return (
    <div className="inspector-pattern">
      <div style={{ padding: "12px 16px 6px" }}>
        <div className="inspector-title">Editing</div>
      </div>
      <div className="crumb">
        <span className="seg"><span className="sw" style={{ background: "var(--c-master)" }} />Project</span>
        <span className="arrow">›</span>
        <span className="seg"><span className="sw" style={{ background: "var(--c-main)" }} />Main Lyrics</span>
        <span className="arrow">›</span>
        <span className="seg active">"Quiet as a runway lamp"</span>
      </div>
      <div className="inspector-body" style={{ flex: 1, overflow: "auto", paddingTop: 4 }}>
        <PatternBodyClip />
      </div>
    </div>
  );
}

function InspectorPatternC() {
  // Flat — chips for tabs, all relevant sections stacked
  return (
    <div className="inspector-pattern">
      <div style={{ padding: "14px 16px 0" }}>
        <div className="inspector-title">Quiet as a runway lamp</div>
        <div style={{ fontSize: 11, color: "var(--fg-3)", marginTop: 2, fontFamily: "var(--font-mono)", letterSpacing: "0.06em", textTransform: "uppercase" }}>
          Main Lyrics · 0:28.40 → 0:32.60
        </div>
      </div>
      <div className="flat-nav">
        <button className="flat-chip active">Clip</button>
        <button className="flat-chip">Style</button>
        <button className="flat-chip">Animation</button>
        <button className="flat-chip">FX</button>
        <button className="flat-chip">↑ Layer</button>
        <button className="flat-chip">↑ Project</button>
      </div>
      <div className="inspector-body" style={{ flex: 1, overflow: "auto", paddingTop: 4 }}>
        <PatternBodyClip />
      </div>
    </div>
  );
}

function PatternBodyClip() {
  return (
    <>
      <div className="disclosure">
        <div className="disclosure-head">Basic <span className="chev"><Icon name="chev-down" size={10} /></span></div>
        <div className="disclosure-body">
          <div className="field" style={{ gridTemplateColumns: "1fr" }}>
            <div className="field-label">Text</div>
            <textarea className="input" rows={2} style={{ height: "auto", padding: 6, lineHeight: 1.4 }} defaultValue="Quiet as a runway lamp" />
          </div>
          <div className="field-row">
            <div className="field"><div className="field-label">In</div><input className="input mono" defaultValue="0:28.40" /></div>
            <div className="field"><div className="field-label">Out</div><input className="input mono" defaultValue="0:32.60" /></div>
            <div className="field"><div className="field-label">Dur</div><input className="input mono" defaultValue="4.20s" /></div>
          </div>
        </div>
      </div>
      <div className="disclosure">
        <div className="disclosure-head">Style overrides <span className="chev"><Icon name="chev-down" size={10} /></span></div>
        <div className="disclosure-body">
          <div style={{ padding: "8px 10px", background: "var(--accent-soft)", border: "1px solid var(--accent)", borderRadius: "var(--r-2)", fontSize: 11 }}>
            <div className="mono" style={{ fontSize: 9.5, color: "var(--accent)", textTransform: "uppercase", letterSpacing: "0.08em" }}>2 overrides active</div>
            <div style={{ color: "var(--fg-2)", marginTop: 2 }}>Font weight · Glow intensity</div>
          </div>
        </div>
      </div>
      <div className="disclosure">
        <div className="disclosure-head">Transitions <span className="chev"><Icon name="chev-down" size={10} /></span></div>
      </div>
      <div className="disclosure">
        <div className="disclosure-head">Advanced <span className="chev"><Icon name="chev-down" size={10} /></span></div>
      </div>
    </>
  );
}

// ============================================================
// Empty state pattern variations
// ============================================================

function EmptyA() {
  // Current — friendly hero
  return (
    <div className="empty-host">
      <div className="state-content">
        <div className="state-icon"><Icon name="headphones" size={26} /></div>
        <div className="state-title">Drop in a master track to start</div>
        <div className="state-desc">
          Lyrixa works clip-first. Add an audio file and we'll bake a waveform, detect vocal segments, and prime the timeline so you can drop lyrics straight onto the beat.
        </div>
        <div className="state-actions">
          <button className="btn-primary"><Icon name="upload" size={14} />Upload audio</button>
          <button className="btn-ghost"><Icon name="file-music" size={14} />Recent</button>
        </div>
      </div>
    </div>
  );
}

function EmptyB() {
  // Diagrammatic — minimal, technical
  return (
    <div className="empty-host">
      <div className="empty-diag">
        <div className="glyph">
          <Icon name="waveform" size={40} style={{ color: "var(--accent)" }} />
        </div>
        <div className="copy">
          <h3>No master loaded</h3>
          <p>Drag an audio file anywhere on this window — or paste a URL. Lyrixa supports WAV, MP3, FLAC, OGG up to 200 MB.</p>
          <button className="btn-primary"><Icon name="upload" size={13} />Choose file</button>
        </div>
      </div>
    </div>
  );
}

function EmptyC() {
  // Stepper / onboarding-style
  return (
    <div className="empty-host">
      <div className="empty-stepper">
        <div className="stepper-title">Set up your project</div>
        <div className="stepper-sub">Three steps to start syncing lyrics. You can skip steps 2-3 and come back later.</div>

        <div className="step-row active">
          <div className="step-num">1</div>
          <div className="step-content">
            <div className="step-title">Add the master track</div>
            <div className="step-desc">The audio your lyrics will sync against. Lyrixa bakes a waveform on import.</div>
            <div className="step-action">
              <button className="btn-primary" style={{ height: 28, padding: "0 12px", fontSize: 12 }}>
                <Icon name="upload" size={12} />Upload audio
              </button>
            </div>
          </div>
        </div>

        <div className="step-row">
          <div className="step-num">2</div>
          <div className="step-content">
            <div className="step-title">Isolate or upload the vocals stem</div>
            <div className="step-desc">Lyrixa uses the stem to suggest segment boundaries and auto-time lyrics.</div>
          </div>
        </div>

        <div className="step-row">
          <div className="step-num">3</div>
          <div className="step-content">
            <div className="step-title">Bring in the lyrics</div>
            <div className="step-desc">Paste plain text, import LRC, or transcribe from the vocals stem.</div>
          </div>
        </div>
      </div>
    </div>
  );
}

window.LyrixaVariants = {
  EditorSlice,
  InspectorPatternA,
  InspectorPatternB,
  InspectorPatternC,
  EmptyA,
  EmptyB,
  EmptyC,
};
