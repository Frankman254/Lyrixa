/* global React, ReactDOM, Icon, Transport, Sidebar, Timeline, Inspector, FloatingPreview, LyrixaData, TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakToggle, TweakSelect */

const { useState, useEffect, useMemo } = React;
const { DEMO_TRACK, DEMO_LAYERS, MAIN_CLIPS, BACKING_CLIPS, FX_CLIPS, ALL_CLIPS } = LyrixaData;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "appState": "editing",
  "previewMode": "floating",
  "fillType": "solid",
  "inspectorContext": "clip",
  "showErrorBanner": false,
  "accent": "amber",
  "sidebarCollapsed": false,
  "inspectorCollapsed": false
}/*EDITMODE-END*/;

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // Playback
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(50.94);
  const [pxPerSec, setPxPerSec] = useState(60);
  const [scrollLeft, setScrollLeft] = useState(2200);

  // Selection
  const [selectedLayerId, setSelectedLayerId] = useState("main");
  const [selectedClipIds, setSelectedClipIds] = useState(["m7"]);

  // Layer state
  const [layerVis, setLayerVis] = useState(() => Object.fromEntries(DEMO_LAYERS.map(l => [l.id, l.visible])));
  const [layerLock, setLayerLock] = useState(() => Object.fromEntries(DEMO_LAYERS.map(l => [l.id, l.locked])));

  // Inspector
  const [activeTab, setActiveTab] = useState("clip");

  // Timeline modes
  const [snapMode, setSnapMode] = useState("beat");
  const [bandMode, setBandMode] = useState("auto");
  const [wavesMode, setWavesMode] = useState("both");

  // Preview
  const [bgMode, setBgMode] = useState("solid");

  // Playback simulation
  useEffect(() => {
    if (!isPlaying) return;
    const id = setInterval(() => {
      setCurrentTime(t => {
        const next = t + 0.05;
        if (next > DEMO_TRACK.durationSec) {
          setIsPlaying(false);
          return DEMO_TRACK.durationSec;
        }
        return next;
      });
    }, 50);
    return () => clearInterval(id);
  }, [isPlaying]);

  // Accent palette swap
  useEffect(() => {
    const root = document.documentElement;
    if (t.accent === "amber") {
      root.style.setProperty("--accent", "oklch(0.82 0.155 75)");
      root.style.setProperty("--accent-strong", "oklch(0.85 0.18 75)");
      root.style.setProperty("--accent-soft", "oklch(0.82 0.155 75 / 0.14)");
      root.style.setProperty("--accent-fg", "oklch(0.20 0.04 75)");
    } else if (t.accent === "teal") {
      root.style.setProperty("--accent", "oklch(0.80 0.13 195)");
      root.style.setProperty("--accent-strong", "oklch(0.83 0.15 195)");
      root.style.setProperty("--accent-soft", "oklch(0.80 0.13 195 / 0.14)");
      root.style.setProperty("--accent-fg", "oklch(0.18 0.04 195)");
    } else if (t.accent === "magenta") {
      root.style.setProperty("--accent", "oklch(0.74 0.20 350)");
      root.style.setProperty("--accent-strong", "oklch(0.78 0.22 350)");
      root.style.setProperty("--accent-soft", "oklch(0.74 0.20 350 / 0.14)");
      root.style.setProperty("--accent-fg", "oklch(0.18 0.04 350)");
    } else if (t.accent === "lime") {
      root.style.setProperty("--accent", "oklch(0.86 0.18 130)");
      root.style.setProperty("--accent-strong", "oklch(0.89 0.20 130)");
      root.style.setProperty("--accent-soft", "oklch(0.86 0.18 130 / 0.14)");
      root.style.setProperty("--accent-fg", "oklch(0.20 0.04 130)");
    }
  }, [t.accent]);

  // Apply inspector context from Tweaks
  useEffect(() => {
    if (t.inspectorContext === "none") {
      setSelectedClipIds([]);
      setActiveTab("project");
    } else if (t.inspectorContext === "layer") {
      setSelectedClipIds([]);
      setActiveTab("layer");
    } else if (t.inspectorContext === "clip") {
      setSelectedClipIds(["m7"]);
      if (activeTab === "project") setActiveTab("clip");
    } else if (t.inspectorContext === "multi-clip") {
      setSelectedClipIds(["m6", "m7", "m8"]);
      setActiveTab("clip");
    }
  }, [t.inspectorContext]);

  // Layers w/ live visible/locked
  const layers = DEMO_LAYERS.map(l => ({
    ...l,
    visible: layerVis[l.id],
    locked: layerLock[l.id],
  }));

  const clipsByLayer = {
    main: MAIN_CLIPS,
    backing: BACKING_CLIPS,
    fx: FX_CLIPS,
    translate: MAIN_CLIPS.map(c => ({ ...c, id: `t_${c.id}`, text: c.text, layer: "translate" })),
  };

  // Derived selection context
  const selectionContext =
    selectedClipIds.length > 0 ? "clip" :
    selectedLayerId ? "layer" :
    "none";

  const selectedLayer = layers.find(l => l.id === selectedLayerId);
  const selectedClips = ALL_CLIPS.filter(c => selectedClipIds.includes(c.id));

  const activeClip = ALL_CLIPS
    .filter(c => c.layer === "main")
    .find(c => currentTime >= c.start && currentTime <= c.end);

  function handleSelectClip(id, additive) {
    if (additive) {
      setSelectedClipIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
    } else {
      setSelectedClipIds([id]);
    }
    if (activeTab !== "clip" && activeTab !== "style" && activeTab !== "anim" && activeTab !== "fx") {
      setActiveTab("clip");
    }
  }

  function handleSelectLayer(id) {
    setSelectedLayerId(id);
    setSelectedClipIds([]);
    setActiveTab("layer");
  }

  function clearSelection() {
    setSelectedClipIds([]);
  }

  function toggleVisible(id) {
    setLayerVis(s => ({ ...s, [id]: !s[id] }));
  }
  function toggleLocked(id) {
    setLayerLock(s => ({ ...s, [id]: !s[id] }));
  }

  const appClass = [
    "app",
    t.sidebarCollapsed ? "sidebar-collapsed" : "",
    t.inspectorCollapsed ? "inspector-collapsed" : "",
    (t.sidebarCollapsed && t.inspectorCollapsed) ? "both-collapsed" : "",
  ].join(" ").trim();

  const emptyMode = t.appState === "no-audio" ? "no-audio"
    : t.appState === "no-lyrics" ? "no-lyrics"
    : t.appState === "loading" ? "loading"
    : null;

  return (
    <>
      <div className={appClass}>
        <Transport
          isPlaying={isPlaying}
          onPlayToggle={() => setIsPlaying(p => !p)}
          currentTime={currentTime}
          durationSec={DEMO_TRACK.durationSec}
          saveState={t.appState === "saving" ? "saving" : t.appState === "dirty" ? "dirty" : "saved"}
          stemActive={emptyMode !== "no-audio"}
          onIsolateVocals={() => setTweak("appState", "loading")}
          onImportLyrics={() => {}}
          onExportProject={() => {}}
          onImportProject={() => {}}
        />

        <Sidebar
          layers={layers}
          selectedLayerId={selectedLayerId}
          onSelectLayer={handleSelectLayer}
          onToggleVisible={toggleVisible}
          onToggleLocked={toggleLocked}
          collapsed={t.sidebarCollapsed}
          onToggleCollapsed={() => setTweak("sidebarCollapsed", !t.sidebarCollapsed)}
        />

        <main className="stage">
          <Timeline
            layers={layers}
            clipsByLayer={clipsByLayer}
            currentTime={currentTime}
            durationSec={DEMO_TRACK.durationSec}
            pxPerSec={pxPerSec}
            setPxPerSec={setPxPerSec}
            scrollLeft={scrollLeft}
            setScrollLeft={setScrollLeft}
            selectedClipIds={selectedClipIds}
            onSelectClip={handleSelectClip}
            onClearSelection={clearSelection}
            emptyMode={emptyMode}
            snapMode={snapMode}
            setSnapMode={setSnapMode}
            bandMode={bandMode}
            setBandMode={setBandMode}
            wavesMode={wavesMode}
            setWavesMode={setWavesMode}
            stemActive={emptyMode !== "no-audio"}
          />
        </main>

        <Inspector
          selectionContext={selectionContext}
          selectedLayer={selectedLayer}
          selectedClipIds={selectedClipIds}
          selectedClips={selectedClips}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          fillType={t.fillType}
          setFillType={(v) => setTweak("fillType", v)}
          collapsed={t.inspectorCollapsed}
          onToggleCollapsed={() => setTweak("inspectorCollapsed", !t.inspectorCollapsed)}
        />

        {!emptyMode && (
          <FloatingPreview
            currentTime={currentTime}
            activeClip={activeClip}
            fillType={t.fillType}
            previewMode={t.previewMode}
            setPreviewMode={(v) => setTweak("previewMode", v)}
            bgMode={bgMode}
            setBgMode={setBgMode}
            initial={{ pos: { x: window.innerWidth - 880, y: window.innerHeight - 420 }, size: { w: 480, h: 280 } }}
          />
        )}

        {t.showErrorBanner && (
          <div className="error-banner">
            <Icon name="alert" size={16} />
            <div>
              <div style={{ fontWeight: 500 }}>Source audio changed on disk</div>
              <div style={{ fontSize: 11, opacity: 0.8, marginTop: 1 }}>Lyrixa detected the master file was modified. Clip timings may drift.</div>
            </div>
            <button onClick={() => setTweak("showErrorBanner", false)}>Reload audio</button>
            <button style={{ background: "transparent", color: "oklch(0.9 0.02 25)" }} onClick={() => setTweak("showErrorBanner", false)}>
              <Icon name="x" size={14} />
            </button>
          </div>
        )}
      </div>

      <TweaksPanel title="Lyrixa Tweaks">
        <TweakSection title="State">
          <TweakSelect
            label="App state"
            value={t.appState}
            options={[
              { value: "editing", label: "Editing (full data)" },
              { value: "no-audio", label: "Empty — no audio" },
              { value: "no-lyrics", label: "Empty — no lyrics" },
              { value: "loading", label: "Loading — analyzing vocals" },
              { value: "dirty", label: "Unsaved changes" },
              { value: "saving", label: "Saving…" },
            ]}
            onChange={(v) => setTweak("appState", v)}
          />
          <TweakToggle
            label="Error banner"
            value={t.showErrorBanner}
            onChange={(v) => setTweak("showErrorBanner", v)}
          />
        </TweakSection>

        <TweakSection title="Inspector">
          <TweakRadio
            label="Context"
            value={t.inspectorContext}
            options={[
              { value: "none", label: "Project" },
              { value: "layer", label: "Layer" },
              { value: "clip", label: "Clip" },
              { value: "multi-clip", label: "Multi-clip (3)" },
            ]}
            onChange={(v) => setTweak("inspectorContext", v)}
          />
          <TweakToggle
            label="Collapse inspector"
            value={t.inspectorCollapsed}
            onChange={(v) => setTweak("inspectorCollapsed", v)}
          />
          <TweakToggle
            label="Collapse layer list"
            value={t.sidebarCollapsed}
            onChange={(v) => setTweak("sidebarCollapsed", v)}
          />
        </TweakSection>

        <TweakSection title="Text fill">
          <TweakRadio
            label="Fill type"
            value={t.fillType}
            options={[
              { value: "solid", label: "Solid" },
              { value: "gradient", label: "Gradient" },
              { value: "texture", label: "Texture" },
            ]}
            onChange={(v) => setTweak("fillType", v)}
          />
        </TweakSection>

        <TweakSection title="Live preview">
          <TweakRadio
            label="Mode"
            value={t.previewMode}
            options={[
              { value: "floating", label: "Floating" },
              { value: "overlay", label: "Overlay" },
              { value: "hidden", label: "Hidden" },
            ]}
            onChange={(v) => setTweak("previewMode", v)}
          />
        </TweakSection>

        <TweakSection title="Theme">
          <TweakRadio
            label="Accent"
            value={t.accent}
            options={[
              { value: "amber", label: "Amber" },
              { value: "teal", label: "Teal" },
              { value: "magenta", label: "Magenta" },
              { value: "lime", label: "Lime" },
            ]}
            onChange={(v) => setTweak("accent", v)}
          />
        </TweakSection>
      </TweaksPanel>
    </>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
