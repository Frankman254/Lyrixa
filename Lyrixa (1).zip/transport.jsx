/* global React, Icon, LyrixaData */
const { useState } = React;
const { DEMO_TRACK } = LyrixaData;

function Transport({
  isPlaying,
  onPlayToggle,
  currentTime,
  durationSec,
  saveState,        // 'saved' | 'dirty' | 'saving'
  stemActive,
  onIsolateVocals,
  onImportLyrics,
  onExportProject,
  onImportProject,
}) {
  function fmtTime(s) {
    const m = Math.floor(s / 60);
    const sec = (s - m * 60).toFixed(2).padStart(5, "0");
    return `${m}:${sec}`;
  }

  return (
    <div className="transport">
      <div className="brand">
        <div className="brand-mark">L</div>
        Lyrixa
      </div>

      <div className="tr-divider" />

      {/* Audio cluster */}
      <button className="song-chip">
        <Icon name="file-music" size={14} style={{ color: "var(--c-master)" }} />
        <span className="title">{DEMO_TRACK.title}</span>
        <span className="duration mono">3:33</span>
      </button>
      <button className="tr-btn" style={{ height: 30, padding: "0 10px", background: "var(--bg-2)", border: "1px solid var(--border)" }} onClick={onIsolateVocals}>
        <Icon name="scan" size={14} />
        Isolate vocals
      </button>
      <button className="tr-btn" style={{ height: 30, padding: "0 10px", background: "var(--bg-2)", border: "1px solid var(--border)" }}>
        <Icon name="upload" size={14} />
        Upload stem
      </button>

      <div className="tr-divider" />

      {/* Playback cluster */}
      <div className="playback-cluster">
        <button className="tr-btn icon-only" style={{ width: 24, padding: 0, color: "var(--fg-2)" }} title="Back to start">
          <Icon name="skip-back" size={14} />
        </button>
        <button className={`play-btn ${isPlaying ? "playing" : ""}`} onClick={onPlayToggle} title={isPlaying ? "Pause (Space)" : "Play (Space)"}>
          <Icon name={isPlaying ? "pause" : "play"} size={14} />
        </button>
        <button className="tr-btn icon-only" style={{ width: 24, padding: 0, color: "var(--fg-2)" }} title="Forward">
          <Icon name="skip-fwd" size={14} />
        </button>
        <span className="time-readout">
          {fmtTime(currentTime)} <span className="total">/ {fmtTime(durationSec)}</span>
        </span>
      </div>

      <div className="tr-divider" />

      {/* Action cluster */}
      <button className="tr-btn primary" style={{ height: 30, padding: "0 12px" }}>
        <Icon name="wand" size={13} />
        Generate timings from vocals
      </button>
      <button className="tr-btn" style={{ height: 30, padding: "0 10px", background: "var(--bg-2)", border: "1px solid var(--border)" }} onClick={onImportLyrics}>
        <Icon name="type" size={13} />
        Import lyrics
      </button>

      <div className="transport-spacer" />

      {/* Right cluster */}
      {stemActive ? (
        <div className="stem-indicator">
          <span className="dot" />
          Vocals stem active
        </div>
      ) : null}

      <div className={`save-status ${saveState === "dirty" ? "dirty" : ""}`}>
        <span className="dot" />
        {saveState === "saved" ? "Saved" : saveState === "saving" ? "Saving…" : "Unsaved"}
      </div>

      <div className="tr-group">
        <button className="tr-btn" onClick={onImportProject}>
          <Icon name="upload" size={12} />
          Import
        </button>
        <button className="tr-btn" onClick={onExportProject}>
          <Icon name="download" size={12} />
          Export
        </button>
      </div>

      <button className="tr-btn icon-only" title="Settings" style={{ width: 30, height: 30, padding: 0, color: "var(--fg-2)" }}>
        <Icon name="settings" size={14} />
      </button>
    </div>
  );
}

window.Transport = Transport;
