/* global React, Icon, LyrixaData */
const { useState: useStateIns } = React;
const { ANIMATION_PRESETS, ACTIVE_PRESETS, FX_PRESETS } = LyrixaData;

// ============================================================
// Primitive controls (used everywhere)
// ============================================================

function Disclosure({ title, defaultOpen = true, count, hint, children }) {
  const [open, setOpen] = useStateIns(defaultOpen);
  return (
    <div className={`disclosure ${!open ? "collapsed" : ""}`}>
      <button className="disclosure-head" onClick={() => setOpen(!open)}>
        <span style={{ display: "flex", alignItems: "center", gap: 6 }}>
          {title}
          {count != null && <span className="badge-count">{count}</span>}
          {hint && <span style={{ fontFamily: "var(--font-sans)", textTransform: "none", letterSpacing: 0, color: "var(--fg-3)", marginLeft: 6 }}>{hint}</span>}
        </span>
        <span className="chev"><Icon name="chev-down" size={12} /></span>
      </button>
      <div className="disclosure-body">{children}</div>
    </div>
  );
}

function Field({ label, children, full }) {
  return (
    <div className="field" style={full ? { gridTemplateColumns: "1fr" } : null}>
      <div className="field-label">{label}</div>
      <div className="field-control">{children}</div>
    </div>
  );
}

function Slider({ value, min = 0, max = 1, step = 0.01, suffix = "", onChange, format }) {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div className="slider">
      <div
        className="slider-track"
        onMouseDown={(e) => {
          const track = e.currentTarget;
          const rect = track.getBoundingClientRect();
          const set = (clientX) => {
            const x = Math.max(0, Math.min(rect.width, clientX - rect.left));
            const pct = x / rect.width;
            let next = min + pct * (max - min);
            if (step) next = Math.round(next / step) * step;
            onChange && onChange(next);
          };
          set(e.clientX);
          const onMove = (ev) => set(ev.clientX);
          const onUp = () => {
            window.removeEventListener("mousemove", onMove);
            window.removeEventListener("mouseup", onUp);
          };
          window.addEventListener("mousemove", onMove);
          window.addEventListener("mouseup", onUp);
        }}
      >
        <div className="slider-fill" style={{ width: `${pct}%` }} />
        <div className="slider-thumb" style={{ left: `${pct}%` }} />
      </div>
      <div className="slider-value">{format ? format(value) : value.toFixed(step < 1 ? 2 : 0) + suffix}</div>
    </div>
  );
}

function Toggle({ on, onChange }) {
  return <button className={`toggle ${on ? "on" : ""}`} onClick={() => onChange(!on)} />;
}

function Segmented({ value, options, onChange }) {
  return (
    <div className="segmented">
      {options.map(opt => (
        <button key={opt.value} className={value === opt.value ? "active" : ""} onClick={() => onChange(opt.value)}>
          {opt.icon && <Icon name={opt.icon} size={12} />}
          {opt.label}
        </button>
      ))}
    </div>
  );
}

function Swatch({ color, hex, suffix }) {
  return (
    <button className="swatch-control">
      <span className="swatch" style={{ "--swatch": color }} />
      <span className="hex">{hex}</span>
      <span className="hex-suffix">{suffix}</span>
    </button>
  );
}

function Stepper({ value, min, max, step = 1, suffix = "", onChange, format }) {
  return (
    <div className="stepper">
      <button onClick={() => onChange(Math.max(min, value - step))}><Icon name="minus" size={11} /></button>
      <input value={format ? format(value) : `${value}${suffix}`} readOnly />
      <button onClick={() => onChange(Math.min(max, value + step))}><Icon name="plus" size={11} /></button>
    </div>
  );
}

function OverrideToggle({ on, onChange, label = "Override" }) {
  return (
    <button className={`override-toggle ${on ? "on" : ""}`} onClick={() => onChange(!on)}>
      <span className="sw" />
      {label}
    </button>
  );
}

// ============================================================
// Tab bodies
// ============================================================

function ProjectTab({ state, setState }) {
  return (
    <>
      <Disclosure title="Basic">
        <Field label="Name">
          <input className="input" defaultValue="Velvet Hours — v3" />
        </Field>
        <Field label="Artist">
          <input className="input" defaultValue="Pale Wolves" />
        </Field>
        <Field label="Tempo">
          <div style={{ display: "flex", gap: 8 }}>
            <Stepper value={92} min={20} max={300} step={1} suffix=" BPM" onChange={() => {}} />
            <button className="tool-btn" style={{ background: "var(--bg-2)", border: "1px solid var(--border)", height: 28, padding: "0 10px" }}>
              <Icon name="wand" size={12} /> Detect
            </button>
          </div>
        </Field>
        <Field label="Time sig">
          <Segmented value="4/4" options={[{value: "4/4", label: "4/4"}, {value: "3/4", label: "3/4"}, {value: "6/8", label: "6/8"}]} onChange={() => {}} />
        </Field>
      </Disclosure>

      <Disclosure title="Project defaults" hint="Apply to all layers">
        <Field label="Font">
          <select className="select"><option>Geist</option><option>Inter</option><option>Space Grotesk</option></select>
        </Field>
        <Field label="Position">
          <Segmented value="bottom" options={[
            { value: "top", label: "Top" }, { value: "center", label: "Center" }, { value: "bottom", label: "Bottom" }
          ]} onChange={() => {}} />
        </Field>
        <Field label="Safe area">
          <Slider value={0.08} min={0} max={0.25} onChange={() => {}} format={v => `${(v*100).toFixed(0)}%`} />
        </Field>
      </Disclosure>

      <Disclosure title="Audio & sync">
        <Field label="Master gain">
          <Slider value={0.0} min={-24} max={6} step={0.1} onChange={() => {}} format={v => `${v.toFixed(1)} dB`} />
        </Field>
        <Field label="Lyrics offset">
          <div style={{ display: "flex", gap: 4 }}>
            {[-0.5, -0.1, 0.1, 0.5].map(d => (
              <button key={d} className="tool-btn" style={{ background: "var(--bg-2)", border: "1px solid var(--border)", height: 26, flex: 1 }}>{d > 0 ? "+" : ""}{d}s</button>
            ))}
          </div>
        </Field>
        <Field label="Snap mode">
          <select className="select"><option>Beat (¼)</option><option>Frame (30 fps)</option><option>Syllable</option><option>Off</option></select>
        </Field>
      </Disclosure>

      <Disclosure title="Preview settings" defaultOpen={false}>
        <Field label="Aspect">
          <Segmented value="16:9" options={[
            { value: "16:9", label: "16:9" }, { value: "9:16", label: "9:16" }, { value: "1:1", label: "1:1" }
          ]} onChange={() => {}} />
        </Field>
        <Field label="Background">
          <Swatch color="#0a0a0a" hex="#0A0A0A" suffix="100%" />
        </Field>
        <Field label="FPS">
          <Segmented value="60" options={[
            { value: "30", label: "30" }, { value: "60", label: "60" }, { value: "120", label: "120" }
          ]} onChange={() => {}} />
        </Field>
      </Disclosure>

      <Disclosure title="Advanced" defaultOpen={false}>
        <Field label="Render mode">
          <select className="select"><option>Editor (DOM)</option><option>Player (DOM)</option><option>Sync recorder</option></select>
        </Field>
        <Field label="Color profile">
          <select className="select"><option>sRGB</option><option>Display P3</option></select>
        </Field>
      </Disclosure>
    </>
  );
}

function LayerTab() {
  return (
    <>
      <Disclosure title="Basic">
        <Field label="Name"><input className="input" defaultValue="Main Lyrics" /></Field>
        <Field label="Color">
          <div style={{ display: "flex", gap: 6 }}>
            {["#d9c773", "#7fc69a", "#8a5cf6", "#f6a25c", "#5cc8f6", "#f06b6b"].map(c => (
              <button key={c} className="swatch" style={{ "--swatch": c, width: 24, height: 24, borderRadius: 4, background: c, border: c === "#d9c773" ? "2px solid var(--fg-0)" : "1px solid var(--border)", cursor: "pointer" }} />
            ))}
          </div>
        </Field>
        <Field label="Z-index"><Stepper value={20} min={0} max={100} step={5} onChange={() => {}} /></Field>
      </Disclosure>

      <Disclosure title="Position">
        <Field label="Preset">
          <select className="select">
            <option>Bottom · center</option><option>Top · center</option><option>Center</option><option>Bottom · left</option><option>Bottom · right</option>
          </select>
        </Field>
        <Field label="Align">
          <Segmented value="center" options={[
            { value: "left", label: "Left" }, { value: "center", label: "Center" }, { value: "right", label: "Right" }
          ]} onChange={() => {}} />
        </Field>
        <Field label="Max width"><Slider value={0.72} min={0.2} max={1} onChange={() => {}} format={v => `${(v*100).toFixed(0)}%`} /></Field>
      </Disclosure>

      <Disclosure title="Audio-reactive" defaultOpen={false} hint="Modulate from audio">
        <Field label="Enabled"><Toggle on={false} onChange={() => {}} /></Field>
        <Field label="Source">
          <Segmented value="vocals" options={[
            { value: "master", label: "Master" }, { value: "vocals", label: "Vocals" }, { value: "est", label: "Est." }
          ]} onChange={() => {}} />
        </Field>
        <Field label="Band">
          <select className="select"><option>Vocals</option><option>Full mix</option><option>Kick</option><option>Bass</option><option>Hi-hat</option></select>
        </Field>
        <Field label="Attack"><Slider value={35} min={0} max={500} step={5} onChange={() => {}} format={v => `${v.toFixed(0)} ms`} /></Field>
        <Field label="Release"><Slider value={220} min={0} max={2000} step={10} onChange={() => {}} format={v => `${v.toFixed(0)} ms`} /></Field>
        <Field label="Threshold"><Slider value={0.08} min={0} max={1} onChange={() => {}} format={v => `${(v*100).toFixed(0)}%`} /></Field>
      </Disclosure>

      <Disclosure title="Defaults applied to clips" hint="Layer style → Clip overrides" defaultOpen={false}>
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          {[
            { name: "Style", desc: "Font · color · stroke · glow" },
            { name: "Animation", desc: "Fade in · breathing · fade out" },
            { name: "FX", desc: "Soft bloom · 50%" },
          ].map(d => (
            <div key={d.name} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "8px 10px", background: "var(--bg-2)", border: "1px solid var(--border)", borderRadius: "var(--r-2)" }}>
              <div>
                <div style={{ fontSize: 12, color: "var(--fg-0)", fontWeight: 500 }}>{d.name}</div>
                <div className="mono" style={{ fontSize: 10, color: "var(--fg-3)" }}>{d.desc}</div>
              </div>
              <button className="tool-btn" style={{ height: 22, padding: "0 8px", color: "var(--fg-2)" }}>Edit</button>
            </div>
          ))}
        </div>
      </Disclosure>
    </>
  );
}

function ClipTab({ selectedCount, selectedClips }) {
  return (
    <>
      <Disclosure title="Basic">
        {selectedCount > 1 ? (
          <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 10px", background: "var(--bg-2)", border: "1px solid var(--border)", borderRadius: "var(--r-2)", marginBottom: 8 }}>
            <Icon name="layers" size={13} style={{ color: "var(--accent)" }} />
            <span className="mono" style={{ fontSize: 11, color: "var(--fg-1)", textTransform: "uppercase", letterSpacing: "0.06em" }}>{selectedCount} clips selected · multi-edit</span>
          </div>
        ) : null}

        <Field label="Text">
          <textarea className="input" rows={2} style={{ height: "auto", padding: 8, resize: "vertical", lineHeight: 1.4 }} defaultValue={selectedClips[0]?.text || "Awake inside the velvet hours"} />
        </Field>
        <div className="field-row">
          <div className="field">
            <div className="field-label">In</div>
            <input className="input mono" defaultValue={selectedClips[0] ? `${Math.floor(selectedClips[0].start/60)}:${(selectedClips[0].start%60).toFixed(2).padStart(5,'0')}` : "0:50.20"} />
          </div>
          <div className="field">
            <div className="field-label">Out</div>
            <input className="input mono" defaultValue={selectedClips[0] ? `${Math.floor(selectedClips[0].end/60)}:${(selectedClips[0].end%60).toFixed(2).padStart(5,'0')}` : "0:56.45"} />
          </div>
          <div className="field">
            <div className="field-label">Duration</div>
            <input className="input mono" defaultValue="6.25s" readOnly />
          </div>
        </div>
        <Field label="Nudge">
          <div style={{ display: "flex", gap: 4 }}>
            {[-0.5, -0.1, -0.05, 0.05, 0.1, 0.5].map((d, i) => (
              <button key={i} className="tool-btn" style={{ background: "var(--bg-2)", border: "1px solid var(--border)", height: 26, flex: 1, fontFamily: "var(--font-mono)", fontSize: 10 }}>
                {d > 0 ? "+" : ""}{d}
              </button>
            ))}
          </div>
        </Field>
      </Disclosure>

      <Disclosure title="Position">
        <Field label="Preset">
          <select className="select">
            <option>Inherit from layer (Bottom)</option><option>Top · center</option><option>Center</option><option>Bottom · right</option>
          </select>
        </Field>
        <Field label="Free X,Y" >
          <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
            <Toggle on={false} onChange={() => {}} />
            <span className="mono" style={{ fontSize: 10, color: "var(--fg-3)", letterSpacing: "0.06em", textTransform: "uppercase" }}>Use coordinates</span>
          </div>
        </Field>
      </Disclosure>

      <Disclosure title="Style overrides" hint="Layer → Clip" defaultOpen={false}>
        <div style={{ padding: "10px 12px", background: "oklch(0.82 0.155 75 / 0.06)", border: "1px solid oklch(0.82 0.155 75 / 0.3)", borderRadius: "var(--r-2)", marginBottom: 10 }}>
          <div className="mono" style={{ fontSize: 10, color: "var(--accent)", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 4 }}>2 overrides active</div>
          <div style={{ fontSize: 11.5, color: "var(--fg-2)" }}>Font weight: <span className="mono" style={{ color: "var(--fg-0)" }}>900</span> · Glow intensity: <span className="mono" style={{ color: "var(--fg-0)" }}>1.0</span></div>
          <button className="tool-btn" style={{ marginTop: 6, color: "var(--fg-3)", padding: "0 8px", height: 22 }}>Reset to layer defaults</button>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
          {[
            { key: "fontWeight", label: "Font weight", val: "900", on: true },
            { key: "fontSize", label: "Font size", val: "—", on: false },
            { key: "color", label: "Text color", val: "—", on: false },
            { key: "stroke", label: "Stroke", val: "—", on: false },
            { key: "glow", label: "Glow intensity", val: "1.0", on: true },
          ].map(o => (
            <div key={o.key} style={{ display: "flex", alignItems: "center", gap: 8, padding: "6px 8px", borderRadius: 4 }}>
              <OverrideToggle on={o.on} onChange={() => {}} label="" />
              <span style={{ fontSize: 11.5, color: o.on ? "var(--fg-0)" : "var(--fg-3)", flex: 1 }}>{o.label}</span>
              <span className="mono" style={{ fontSize: 11, color: o.on ? "var(--fg-0)" : "var(--fg-3)" }}>{o.val}</span>
            </div>
          ))}
        </div>
      </Disclosure>

      <Disclosure title="Transitions">
        <div className="field-row">
          <div className="field">
            <div className="field-label">In</div>
            <select className="select"><option>Fade</option><option>Slide up</option><option>Blur in</option><option>Glow pop</option></select>
          </div>
          <div className="field">
            <div className="field-label">Out</div>
            <select className="select"><option>Fade out</option><option>Blur out</option><option>Scale out</option></select>
          </div>
        </div>
        <Field label="Duration"><Slider value={360} min={80} max={2000} step={10} onChange={() => {}} format={v => `${v.toFixed(0)} ms`} /></Field>
        <Field label="Linger out"><Slider value={420} min={0} max={2000} step={10} onChange={() => {}} format={v => `${v.toFixed(0)} ms`} /></Field>
      </Disclosure>

      <Disclosure title="Advanced" defaultOpen={false}>
        <Field label="Locked"><Toggle on={false} onChange={() => {}} /></Field>
        <Field label="Muted"><Toggle on={false} onChange={() => {}} /></Field>
        <Field label="Style preset">
          <select className="select"><option>None (use layer)</option><option>Concert main</option><option>Subtitle</option></select>
        </Field>
      </Disclosure>
    </>
  );
}

function StyleTab({ fillType, setFillType }) {
  return (
    <>
      <Disclosure title="Typography">
        <Field label="Font">
          <select className="select"><option>Geist</option><option>Inter</option><option>Space Grotesk</option><option>JetBrains Mono</option></select>
        </Field>
        <div className="field-row">
          <div className="field">
            <div className="field-label">Size</div>
            <div className="input-wrap"><input className="input mono with-suffix" defaultValue="2.8" /><span className="suffix">rem</span></div>
          </div>
          <div className="field">
            <div className="field-label">Weight</div>
            <select className="select"><option>400</option><option>500</option><option>600</option><option>700</option><option selected>800</option><option>900</option></select>
          </div>
        </div>
        <div className="field-row">
          <div className="field">
            <div className="field-label">Letter spacing</div>
            <div className="input-wrap"><input className="input mono with-suffix" defaultValue="-0.5" /><span className="suffix">px</span></div>
          </div>
          <div className="field">
            <div className="field-label">Line height</div>
            <input className="input mono" defaultValue="1.2" />
          </div>
        </div>
        <Field label="Case">
          <Segmented value="none" options={[
            { value: "none", label: "Aa" }, { value: "upper", label: "AA" }, { value: "lower", label: "aa" }
          ]} onChange={() => {}} />
        </Field>
      </Disclosure>

      <Disclosure title="Fill">
        <div className="fill-tabs">
          <button className={`fill-tab ${fillType === "solid" ? "active" : ""}`} onClick={() => setFillType("solid")}>
            <span className="preview-swatch" style={{ background: "#ffffff" }} />
            <span className="pname">Solid</span>
          </button>
          <button className={`fill-tab ${fillType === "gradient" ? "active" : ""}`} onClick={() => setFillType("gradient")}>
            <span className="preview-swatch" style={{ background: "linear-gradient(135deg, #fff, #80eaff, #ff6bd5)" }} />
            <span className="pname">Gradient</span>
          </button>
          <button className={`fill-tab ${fillType === "texture" ? "active" : ""}`} onClick={() => setFillType("texture")}>
            <span className="preview-swatch" style={{ background: "url('data:image/svg+xml;utf8,<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 32 32\"><rect width=\"32\" height=\"32\" fill=\"%23d97757\"/><circle cx=\"10\" cy=\"10\" r=\"6\" fill=\"%23f3c886\"/><path d=\"M0 22 Q16 14 32 24 V32 H0\" fill=\"%237fc69a\"/></svg>')", backgroundSize: "cover" }} />
            <span className="pname">Texture</span>
          </button>
        </div>

        {fillType === "solid" && (
          <Field label="Color">
            <Swatch color="#ffffff" hex="#FFFFFF" suffix="100%" />
          </Field>
        )}

        {fillType === "gradient" && (
          <>
            <div className="gradient-preview" style={{ "--gradient": "linear-gradient(110deg, #ffffff 0%, #80eaff 45%, #ff6bd5 100%)" }} />
            <div className="field-row" style={{ marginTop: 10 }}>
              <div className="field">
                <div className="field-label">Color A</div>
                <Swatch color="#ffffff" hex="#FFFFFF" />
              </div>
              <div className="field">
                <div className="field-label">Color B</div>
                <Swatch color="#80eaff" hex="#80EAFF" />
              </div>
            </div>
            <Field label="Angle">
              <Slider value={110} min={0} max={360} step={1} onChange={() => {}} format={v => `${v.toFixed(0)}°`} />
            </Field>
          </>
        )}

        {fillType === "texture" && (
          <>
            <div className="texture-drop">
              <div className="thumb" style={{ background: "url('data:image/svg+xml;utf8,<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 40 40\"><rect width=\"40\" height=\"40\" fill=\"%23d97757\"/><circle cx=\"12\" cy=\"12\" r=\"7\" fill=\"%23f3c886\"/><path d=\"M0 28 Q20 18 40 30 V40 H0\" fill=\"%237fc69a\"/></svg>')", backgroundSize: "cover" }} />
              <div className="info">
                <div className="name">amber-clouds-04.jpg</div>
                <div className="meta">2048×2048 · JPG · 482 KB</div>
              </div>
              <button className="tool-btn icon-only" title="Replace" style={{ width: 28, height: 28 }}><Icon name="refresh" size={12} /></button>
            </div>
            <div style={{ marginTop: 10 }}>
              <Field label="Fit">
                <Segmented value="cover" options={[
                  { value: "cover", label: "Cover" }, { value: "contain", label: "Contain" }
                ]} onChange={() => {}} />
              </Field>
              <Field label="Scale"><Slider value={1.0} min={0.2} max={3} step={0.05} onChange={() => {}} format={v => `${v.toFixed(2)}x`} /></Field>
              <Field label="Offset X"><Slider value={0} min={-1} max={1} onChange={() => {}} format={v => `${(v*100).toFixed(0)}%`} /></Field>
              <Field label="Offset Y"><Slider value={0} min={-1} max={1} onChange={() => {}} format={v => `${(v*100).toFixed(0)}%`} /></Field>
              <Field label="Opacity"><Slider value={1.0} min={0} max={1} onChange={() => {}} format={v => `${(v*100).toFixed(0)}%`} /></Field>
              <Field label="Brightness"><Slider value={1.08} min={0.5} max={2} step={0.01} onChange={() => {}} format={v => `${v.toFixed(2)}`} /></Field>
              <Field label="Contrast"><Slider value={1.22} min={0.5} max={2} step={0.01} onChange={() => {}} format={v => `${v.toFixed(2)}`} /></Field>
              <Field label="Saturation"><Slider value={1.18} min={0} max={2} step={0.01} onChange={() => {}} format={v => `${v.toFixed(2)}`} /></Field>
            </div>
          </>
        )}
      </Disclosure>

      <Disclosure title="Glow & shadow">
        <Field label="Glow color"><Swatch color="oklch(0.85 0.18 75)" hex="#FFC470" /></Field>
        <Field label="Glow intensity"><Slider value={0.7} min={0} max={2} step={0.01} onChange={() => {}} format={v => v.toFixed(2)} /></Field>
        <Field label="Shadow"><Slider value={0.5} min={0} max={1} step={0.01} onChange={() => {}} format={v => `${(v*100).toFixed(0)}%`} /></Field>
        <Field label="Blur"><Slider value={0} min={0} max={20} step={0.5} onChange={() => {}} format={v => `${v.toFixed(1)} px`} /></Field>
      </Disclosure>

      <Disclosure title="Stroke" defaultOpen={false}>
        <Field label="Width"><Slider value={0} min={0} max={8} step={0.5} onChange={() => {}} format={v => `${v.toFixed(1)} px`} /></Field>
        <Field label="Color"><Swatch color="rgba(0,0,0,0.65)" hex="#000000" suffix="65%" /></Field>
      </Disclosure>

      <Disclosure title="Background pill" defaultOpen={false}>
        <Field label="Enabled"><Toggle on={false} onChange={() => {}} /></Field>
        <Field label="Color"><Swatch color="#000" hex="#000000" suffix="28%" /></Field>
      </Disclosure>
    </>
  );
}

function FxAnimTab({ kind }) {
  const presets = kind === "fx" ? FX_PRESETS : kind === "anim-active" ? ACTIVE_PRESETS : ANIMATION_PRESETS;
  const [active, setActive] = useStateIns(presets[1]?.id || presets[0].id);

  return (
    <>
      {kind === "anim" && (
        <Disclosure title="Transition presets">
          <div className="preset-grid">
            {ANIMATION_PRESETS.map(p => (
              <button key={p.id} className={`preset-card ${active === p.id ? "active" : ""}`} onClick={() => setActive(p.id)}>
                <div className="preset-thumb">
                  <div className={`anim-thumb-A ${p.thumbClass}`}><span>Aa</span></div>
                </div>
                <div className="preset-name">{p.label}</div>
                <div className="preset-meta">{p.meta}</div>
              </button>
            ))}
          </div>
        </Disclosure>
      )}

      {kind === "anim-active" && (
        <Disclosure title="Active animation" hint="Loops while clip is on screen">
          <div className="preset-grid">
            {ACTIVE_PRESETS.map(p => (
              <button key={p.id} className={`preset-card ${active === p.id ? "active" : ""}`} onClick={() => setActive(p.id)}>
                <div className="preset-thumb">
                  <div className={`anim-thumb-A ${p.thumbClass}`}><span>{p.label === "None" ? "Aa" : "Aa"}</span></div>
                </div>
                <div className="preset-name">{p.label}</div>
                <div className="preset-meta">{p.meta}</div>
              </button>
            ))}
          </div>
        </Disclosure>
      )}

      {kind === "fx" && (
        <Disclosure title="FX preset">
          <div style={{ marginBottom: 10, display: "flex", alignItems: "center", gap: 8 }}>
            <Toggle on={true} onChange={() => {}} />
            <span style={{ fontSize: 12, color: "var(--fg-1)" }}>FX enabled</span>
            <span className="mono" style={{ marginLeft: "auto", fontSize: 10, color: "var(--fg-3)", textTransform: "uppercase", letterSpacing: "0.06em" }}>GPU shader</span>
          </div>
          <div className="preset-grid">
            {FX_PRESETS.map(p => (
              <button key={p.id} className={`preset-card ${active === p.id ? "active" : ""}`} onClick={() => setActive(p.id)}>
                <div className="preset-thumb">
                  <div className={`anim-thumb-A ${p.thumbClass}`}><span>Aa</span></div>
                </div>
                <div className="preset-name">{p.label}</div>
                <div className="preset-meta">{p.meta}</div>
              </button>
            ))}
          </div>
        </Disclosure>
      )}

      <Disclosure title="Controls">
        <Field label="Intensity"><Slider value={0.7} min={0} max={1} onChange={() => {}} format={v => `${(v*100).toFixed(0)}%`} /></Field>
        <Field label="Speed"><Slider value={1} min={0.2} max={3} step={0.05} onChange={() => {}} format={v => `${v.toFixed(2)}x`} /></Field>
        {kind === "fx" && (
          <>
            <Field label="Blend">
              <select className="select"><option>Normal</option><option>Screen</option><option>Multiply</option><option>Overlay</option><option>Plus-lighter</option></select>
            </Field>
            <Field label="Opacity"><Slider value={1.0} min={0} max={1} onChange={() => {}} format={v => `${(v*100).toFixed(0)}%`} /></Field>
          </>
        )}
      </Disclosure>

      <Disclosure title="Audio-react binding" defaultOpen={false} hint="Sync to vocals/beat">
        <Field label="Bind to"><select className="select"><option>None</option><option>Vocals envelope</option><option>Kick peak</option><option>Bass envelope</option></select></Field>
        <Field label="Amount"><Slider value={0.5} min={0} max={1} onChange={() => {}} format={v => `${(v*100).toFixed(0)}%`} /></Field>
      </Disclosure>

      <Disclosure title="Advanced" defaultOpen={false}>
        <Field label="Easing"><select className="select"><option>ease-out</option><option>ease-in-out</option><option>spring</option><option>linear</option></select></Field>
        <Field label="Stagger" ><Slider value={0} min={0} max={200} step={5} onChange={() => {}} format={v => `${v.toFixed(0)} ms`} /></Field>
        <Field label="Color A"><Swatch color="#60f5ff" hex="#60F5FF" /></Field>
        <Field label="Color B"><Swatch color="#ff4fd8" hex="#FF4FD8" /></Field>
      </Disclosure>
    </>
  );
}

// ============================================================
// Inspector shell
// ============================================================

const TABS = [
  { id: "project", label: "Project" },
  { id: "layer", label: "Layer" },
  { id: "clip", label: "Clip" },
  { id: "style", label: "Style" },
  { id: "anim", label: "Animation" },
  { id: "fx", label: "FX" },
];

function Inspector({
  selectionContext,   // 'none' | 'layer' | 'clip'
  selectedLayer,
  selectedClipIds,
  selectedClips,
  activeTab,
  setActiveTab,
  fillType,
  setFillType,
  collapsed,
  onToggleCollapsed,
}) {
  if (collapsed) {
    return (
      <aside className="inspector" style={{ width: 44, padding: 8 }}>
        <button className="tool-btn icon-only" onClick={onToggleCollapsed} title="Expand inspector" style={{ width: 28, height: 28 }}>
          <Icon name="panel-right" size={14} />
        </button>
      </aside>
    );
  }

  const ctxLabel = selectionContext === "clip"
    ? `${selectedClipIds.length} clip${selectedClipIds.length === 1 ? "" : "s"}`
    : selectionContext === "layer" ? selectedLayer?.name : "Project defaults";

  return (
    <aside className="inspector">
      <div className="inspector-header">
        <div>
          <div className="inspector-title">Inspector</div>
          <div className="inspector-subject">
            <span>{ctxLabel}</span>
            <span className="ctx-pill">
              <span className="dot" />
              {selectionContext === "clip" ? "Clip" : selectionContext === "layer" ? "Layer" : "Project"}
            </span>
          </div>
        </div>
        <button className="tool-btn icon-only" onClick={onToggleCollapsed} title="Collapse" style={{ width: 24, height: 24 }}>
          <Icon name="panel-right" size={12} />
        </button>
      </div>

      <div className="inspector-tabs">
        {TABS.map(t => {
          const enabled =
            t.id === "project" ? true :
            t.id === "layer" ? selectionContext !== "none" || true :
            t.id === "clip" ? selectionContext === "clip" :
            true;
          return (
            <button
              key={t.id}
              className={`itab ${activeTab === t.id ? "active" : ""}`}
              onClick={() => enabled && setActiveTab(t.id)}
              style={enabled ? null : { color: "var(--fg-4)", cursor: "not-allowed" }}
            >
              {t.label}
              {t.id === "clip" && selectionContext === "clip" && (<span className="dot-override" />)}
            </button>
          );
        })}
      </div>

      <div className="inspector-body">
        {activeTab === "project" && <ProjectTab />}
        {activeTab === "layer" && <LayerTab />}
        {activeTab === "clip" && selectionContext === "clip" && (
          <ClipTab selectedCount={selectedClipIds.length} selectedClips={selectedClips} />
        )}
        {activeTab === "clip" && selectionContext !== "clip" && (
          <div style={{ padding: "32px 0", textAlign: "center" }}>
            <Icon name="layers" size={28} style={{ color: "var(--fg-4)", marginBottom: 12 }} />
            <div style={{ fontSize: 13, color: "var(--fg-1)", marginBottom: 6 }}>No clip selected</div>
            <div style={{ fontSize: 12, color: "var(--fg-3)", maxWidth: 240, margin: "0 auto" }}>
              Click a clip in the timeline to edit it. Shift-click to multi-select and edit in bulk.
            </div>
          </div>
        )}
        {activeTab === "style" && <StyleTab fillType={fillType} setFillType={setFillType} />}
        {activeTab === "anim" && (
          <>
            <FxAnimTab kind="anim" />
            <FxAnimTab kind="anim-active" />
          </>
        )}
        {activeTab === "fx" && <FxAnimTab kind="fx" />}
      </div>
    </aside>
  );
}

window.Inspector = Inspector;
