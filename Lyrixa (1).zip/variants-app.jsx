/* global React, ReactDOM, DesignCanvas, DCSection, DCArtboard, LyrixaVariants */

const { EditorSlice, InspectorPatternA, InspectorPatternB, InspectorPatternC, EmptyA, EmptyB, EmptyC } = LyrixaVariants;

function App() {
  return (
    <DesignCanvas title="Lyrixa · Variant exploration" subtitle="Side-by-side directions for theme, inspector pattern, and empty-state language.">

      <DCSection
        id="themes"
        title="Theme directions"
        subtitle="Same data, three aesthetic positions. Pick whichever the brand is going to support."
      >
        <DCArtboard id="theme-a" label="A · Warm Studio" width={1100} height={620}>
          <EditorSlice themeClass="theme-warm" label="Warm Studio" accentName="Amber" />
        </DCArtboard>
        <DCArtboard id="theme-b" label="B · Stage Black" width={1100} height={620}>
          <EditorSlice themeClass="theme-stage" label="Stage Black" accentName="Neon green" />
        </DCArtboard>
        <DCArtboard id="theme-c" label="C · Atelier" width={1100} height={620}>
          <EditorSlice themeClass="theme-atelier" label="Atelier" accentName="Terracotta" />
        </DCArtboard>
      </DCSection>

      <DCSection
        id="inspector"
        title="Inspector context handling"
        subtitle="How we communicate what's being edited. Same data, three navigation models."
      >
        <DCArtboard id="ins-a" label="A · Tabs + context pill (current)" width={380} height={620}>
          <InspectorPatternA />
        </DCArtboard>
        <DCArtboard id="ins-b" label="B · Breadcrumb" width={380} height={620}>
          <InspectorPatternB />
        </DCArtboard>
        <DCArtboard id="ins-c" label="C · Flat chips · clip-first" width={380} height={620}>
          <InspectorPatternC />
        </DCArtboard>
      </DCSection>

      <DCSection
        id="empty"
        title="Empty state language"
        subtitle="How the app feels before anything is loaded."
      >
        <DCArtboard id="empty-a" label="A · Friendly hero (current)" width={620} height={420}>
          <EmptyA />
        </DCArtboard>
        <DCArtboard id="empty-b" label="B · Diagrammatic" width={620} height={420}>
          <EmptyB />
        </DCArtboard>
        <DCArtboard id="empty-c" label="C · Onboarding stepper" width={620} height={420}>
          <EmptyC />
        </DCArtboard>
      </DCSection>

    </DesignCanvas>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
