/* global React */
/* Lyrixa icons — minimal stroke-based set */

const Icon = ({ name, size = 16, ...rest }) => {
  const s = { width: size, height: size, ...rest.style };
  const common = {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.6,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    ...rest,
    style: s,
  };
  switch (name) {
    case "play":
      return (
        <svg {...common}><path d="M8 5.5v13l11-6.5z" fill="currentColor" stroke="none" /></svg>
      );
    case "pause":
      return (
        <svg {...common}><rect x="7" y="5" width="3.5" height="14" rx="0.5" fill="currentColor" stroke="none" /><rect x="13.5" y="5" width="3.5" height="14" rx="0.5" fill="currentColor" stroke="none" /></svg>
      );
    case "stop":
      return (<svg {...common}><rect x="6" y="6" width="12" height="12" rx="1" fill="currentColor" stroke="none" /></svg>);
    case "skip-back":
      return (<svg {...common}><path d="M19 5v14L9 12zM6 5v14" /></svg>);
    case "skip-fwd":
      return (<svg {...common}><path d="M5 5v14l10-7zM18 5v14" /></svg>);
    case "rec":
      return (<svg {...common}><circle cx="12" cy="12" r="6" fill="currentColor" stroke="none" /></svg>);
    case "plus":
      return (<svg {...common}><path d="M12 5v14M5 12h14" /></svg>);
    case "minus":
      return (<svg {...common}><path d="M5 12h14" /></svg>);
    case "x":
      return (<svg {...common}><path d="M6 6l12 12M6 18L18 6" /></svg>);
    case "chev-down":
      return (<svg {...common}><path d="M6 9l6 6 6-6" /></svg>);
    case "chev-up":
      return (<svg {...common}><path d="M6 15l6-6 6 6" /></svg>);
    case "chev-right":
      return (<svg {...common}><path d="M9 6l6 6-6 6" /></svg>);
    case "chev-left":
      return (<svg {...common}><path d="M15 6l-6 6 6 6" /></svg>);
    case "eye":
      return (<svg {...common}><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z" /><circle cx="12" cy="12" r="3" /></svg>);
    case "eye-off":
      return (<svg {...common}><path d="M3 3l18 18" /><path d="M10.6 6.1A10.5 10.5 0 0 1 12 6c6.5 0 10 6 10 6a16.7 16.7 0 0 1-3.5 4.2M6.4 6.4A16.5 16.5 0 0 0 2 12s3.5 6 10 6c1.4 0 2.7-.3 3.9-.7" /><path d="M14.1 14.1a3 3 0 0 1-4.2-4.2" /></svg>);
    case "lock":
      return (<svg {...common}><rect x="5" y="11" width="14" height="9" rx="2" /><path d="M8 11V8a4 4 0 0 1 8 0v3" /></svg>);
    case "lock-open":
      return (<svg {...common}><rect x="5" y="11" width="14" height="9" rx="2" /><path d="M8 11V8a4 4 0 0 1 7.5-2" /></svg>);
    case "mic":
      return (<svg {...common}><rect x="9" y="3" width="6" height="12" rx="3" /><path d="M5 11a7 7 0 0 0 14 0M12 18v3" /></svg>);
    case "waveform":
      return (<svg {...common}><path d="M3 12h2M7 8v8M11 5v14M15 9v6M19 11v2M21 12h0" /></svg>);
    case "layers":
      return (<svg {...common}><path d="M12 2l9 5-9 5-9-5 9-5z" /><path d="M3 12l9 5 9-5M3 17l9 5 9-5" /></svg>);
    case "music":
      return (<svg {...common}><path d="M9 17V5l12-2v12" /><circle cx="6" cy="17" r="3" /><circle cx="18" cy="15" r="3" /></svg>);
    case "type":
      return (<svg {...common}><path d="M4 7V5h16v2M9 5v14M9 19h6" /></svg>);
    case "palette":
      return (<svg {...common}><path d="M12 2a10 10 0 1 0 0 20c1.5 0 2-1 1.5-2-.5-1 .5-2 2-2H17a5 5 0 0 0 5-5 8 8 0 0 0-10-11z" /><circle cx="7.5" cy="10.5" r=".8" fill="currentColor" stroke="none" /><circle cx="12" cy="7.5" r=".8" fill="currentColor" stroke="none" /><circle cx="16.5" cy="10.5" r=".8" fill="currentColor" stroke="none" /></svg>);
    case "image":
      return (<svg {...common}><rect x="3" y="3" width="18" height="18" rx="2" /><circle cx="8.5" cy="9" r="1.5" /><path d="M21 16l-5-5L5 21" /></svg>);
    case "sparkles":
      return (<svg {...common}><path d="M5 3v4M3 5h4M19 14v4M17 16h4M11 4l2 5 5 2-5 2-2 5-2-5-5-2 5-2z" /></svg>);
    case "wand":
      return (<svg {...common}><path d="M15 4l5 5M3 21l13-13M9 4l2 2M19 14l2 2M4 14l2 2" /></svg>);
    case "settings":
      return (<svg {...common}><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3h0a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8v0a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z" /></svg>);
    case "search":
      return (<svg {...common}><circle cx="11" cy="11" r="7" /><path d="M21 21l-4.3-4.3" /></svg>);
    case "upload":
      return (<svg {...common}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12" /></svg>);
    case "download":
      return (<svg {...common}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3" /></svg>);
    case "scissors":
      return (<svg {...common}><circle cx="6" cy="6" r="3" /><circle cx="6" cy="18" r="3" /><path d="M20 4L8.12 15.88M14.47 14.48L20 20M8.12 8.12L12 12" /></svg>);
    case "magnet":
      return (<svg {...common}><path d="M6 15a6 6 0 0 0 12 0V3h-4v12a2 2 0 0 1-4 0V3H6z" /></svg>);
    case "trash":
      return (<svg {...common}><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" /></svg>);
    case "drag":
      return (<svg {...common}><circle cx="9" cy="6" r=".8" fill="currentColor" /><circle cx="15" cy="6" r=".8" fill="currentColor" /><circle cx="9" cy="12" r=".8" fill="currentColor" /><circle cx="15" cy="12" r=".8" fill="currentColor" /><circle cx="9" cy="18" r=".8" fill="currentColor" /><circle cx="15" cy="18" r=".8" fill="currentColor" /></svg>);
    case "expand":
      return (<svg {...common}><path d="M3 9V3h6M21 9V3h-6M3 15v6h6M21 15v6h-6" /></svg>);
    case "minimize":
      return (<svg {...common}><path d="M9 3v6H3M15 3v6h6M9 21v-6H3M15 21v-6h6" /></svg>);
    case "overlay":
      return (<svg {...common}><rect x="3" y="3" width="14" height="14" rx="2" /><rect x="7" y="7" width="14" height="14" rx="2" fill="currentColor" fillOpacity="0.2" /></svg>);
    case "file-music":
      return (<svg {...common}><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><path d="M14 2v6h6M10 17V11l4 1v5" /><circle cx="9" cy="17" r="1.5" /><circle cx="13" cy="18" r="1.5" /></svg>);
    case "scan":
      return (<svg {...common}><path d="M3 7V5a2 2 0 0 1 2-2h2M17 3h2a2 2 0 0 1 2 2v2M21 17v2a2 2 0 0 1-2 2h-2M7 21H5a2 2 0 0 1-2-2v-2M7 12h10" /></svg>);
    case "info":
      return (<svg {...common}><circle cx="12" cy="12" r="10" /><path d="M12 16v-4M12 8h.01" /></svg>);
    case "alert":
      return (<svg {...common}><path d="M10.3 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" /><path d="M12 9v4M12 17h.01" /></svg>);
    case "refresh":
      return (<svg {...common}><path d="M3 12a9 9 0 0 1 15-6.7L21 8M21 3v5h-5M21 12a9 9 0 0 1-15 6.7L3 16M3 21v-5h5" /></svg>);
    case "loader":
      return (<svg {...common}><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83" /></svg>);
    case "check":
      return (<svg {...common}><path d="M5 12l5 5L20 7" /></svg>);
    case "headphones":
      return (<svg {...common}><path d="M3 18v-6a9 9 0 0 1 18 0v6" /><path d="M21 19a2 2 0 0 1-2 2h-1v-7h2a1 1 0 0 1 1 1zM3 19a2 2 0 0 0 2 2h1v-7H4a1 1 0 0 0-1 1z" /></svg>);
    case "shuffle":
      return (<svg {...common}><path d="M16 3h5v5M4 20L21 3M21 16v5h-5M15 15l6 6M4 4l5 5" /></svg>);
    case "panel-left":
      return (<svg {...common}><rect x="3" y="3" width="18" height="18" rx="2" /><path d="M9 3v18" /></svg>);
    case "panel-right":
      return (<svg {...common}><rect x="3" y="3" width="18" height="18" rx="2" /><path d="M15 3v18" /></svg>);
    case "circle":
      return (<svg {...common}><circle cx="12" cy="12" r="8" /></svg>);
    default:
      return <svg {...common} />;
  }
};

window.Icon = Icon;
