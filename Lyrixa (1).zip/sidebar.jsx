/* global React, Icon */

function LayerRow({ layer, selected, onSelect, onToggleVisible, onToggleLocked }) {
  return (
    <div
      className={`layer-row ${selected ? "selected" : ""} ${(!layer.visible || layer.locked) ? "has-state" : ""}`}
      onClick={() => onSelect(layer.id)}
    >
      <span className="swatch" style={{ background: layer.color }} />
      <div className="lname">{layer.name}</div>
      <span className="lmeta">{layer.clipCount}</span>
      <div className="layer-actions">
        <button
          className={layer.visible ? "active" : "muted-icon"}
          onClick={(e) => { e.stopPropagation(); onToggleVisible(layer.id); }}
          title={layer.visible ? "Hide layer" : "Show layer"}
        >
          <Icon name={layer.visible ? "eye" : "eye-off"} size={12} />
        </button>
        <button
          className={layer.locked ? "active" : ""}
          onClick={(e) => { e.stopPropagation(); onToggleLocked(layer.id); }}
          title={layer.locked ? "Unlock" : "Lock"}
        >
          <Icon name={layer.locked ? "lock" : "lock-open"} size={12} />
        </button>
      </div>
    </div>
  );
}

function Sidebar({
  layers,
  selectedLayerId,
  onSelectLayer,
  onToggleVisible,
  onToggleLocked,
  collapsed,
  onToggleCollapsed,
}) {
  if (collapsed) {
    return (
      <div className="sidebar" style={{ width: 44, padding: 8 }}>
        <button className="tool-btn icon-only" onClick={onToggleCollapsed} title="Expand sidebar" style={{ width: 28, height: 28 }}>
          <Icon name="panel-left" size={14} />
        </button>
      </div>
    );
  }

  return (
    <aside className="sidebar">
      <div className="sidebar-header">
        <div className="label-eyebrow">Layers</div>
        <button className="tool-btn icon-only" onClick={onToggleCollapsed} title="Collapse" style={{ width: 22, height: 22 }}>
          <Icon name="panel-left" size={12} />
        </button>
      </div>

      <div className="sidebar-body">
        <div className="sidebar-section">
          <div className="section-title">
            Tracks
            <button title="Add layer"><Icon name="plus" size={11} /></button>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 1 }}>
            {layers.map(l => (
              <LayerRow
                key={l.id}
                layer={l}
                selected={selectedLayerId === l.id}
                onSelect={onSelectLayer}
                onToggleVisible={onToggleVisible}
                onToggleLocked={onToggleLocked}
              />
            ))}
          </div>
          <button className="add-layer-btn">
            <Icon name="plus" size={12} />
            New layer
          </button>
        </div>

        <div className="sidebar-section">
          <div className="section-title">Presets</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 1 }}>
            {["Concert", "Lyric video", "Vertical clip", "Minimal subtitles"].map(p => (
              <div key={p} className="layer-row" style={{ paddingLeft: 8 }}>
                <Icon name="palette" size={12} style={{ color: "var(--fg-3)" }} />
                <div className="lname" style={{ fontSize: 12 }}>{p}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="sidebar-section">
          <div className="section-title">
            Library
            <button title="Search"><Icon name="search" size={11} /></button>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 1 }}>
            <div className="layer-row" style={{ paddingLeft: 8 }}>
              <Icon name="image" size={12} style={{ color: "var(--fg-3)" }} />
              <div className="lname" style={{ fontSize: 12 }}>Textures</div>
              <span className="lmeta">12</span>
            </div>
            <div className="layer-row" style={{ paddingLeft: 8 }}>
              <Icon name="type" size={12} style={{ color: "var(--fg-3)" }} />
              <div className="lname" style={{ fontSize: 12 }}>Fonts</div>
              <span className="lmeta">8</span>
            </div>
            <div className="layer-row" style={{ paddingLeft: 8 }}>
              <Icon name="palette" size={12} style={{ color: "var(--fg-3)" }} />
              <div className="lname" style={{ fontSize: 12 }}>Color sets</div>
              <span className="lmeta">5</span>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}

window.Sidebar = Sidebar;
