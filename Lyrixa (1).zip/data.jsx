/* global window */

// ============================================================
// Demo data — original content (no copyrighted lyrics)
// ============================================================

const DEMO_TRACK = {
  title: "Velvet Hours — Pale Wolves (Studio Mix v3).wav",
  durationSec: 213,
  bpm: 92,
};

const DEMO_LAYERS = [
  { id: "main", name: "Main Lyrics", type: "lyrics", color: "var(--c-main)", pos: "Bottom", visible: true, locked: false, clipCount: 18 },
  { id: "backing", name: "Backing Vocals", type: "backing", color: "var(--c-backing)", pos: "Top", visible: true, locked: false, clipCount: 7 },
  { id: "fx", name: "FX / Adlibs", type: "fx", color: "var(--c-fx)", pos: "Top right", visible: true, locked: false, clipCount: 5 },
  { id: "translate", name: "Translation · ES", type: "annotation", color: "oklch(0.70 0.10 200)", pos: "Bottom", visible: false, locked: false, clipCount: 18 },
];

// Original verse content invented for the demo. NOT real song lyrics.
const MAIN_CLIPS = [
  { id: "m1", text: "Awake inside the velvet hours", start: 12.4,  end: 17.2, layer: "main" },
  { id: "m2", text: "Streetlights drown in violet rain",   start: 17.6, end: 22.4, layer: "main" },
  { id: "m3", text: "I traced your name across the glass", start: 22.8, end: 28.0, layer: "main" },
  { id: "m4", text: "Quiet as a runway lamp",              start: 28.4, end: 32.6, layer: "main" },
  { id: "m5", text: "Hold the hush, hold the breath",      start: 36.0, end: 41.0, layer: "main" },
  { id: "m6", text: "Until the morning learns our shape",  start: 41.4, end: 47.0, layer: "main" },
  { id: "m7", text: "Velvet hours, velvet hours",          start: 50.0, end: 56.5, layer: "main" },
  { id: "m8", text: "Hold me where the noise can't reach", start: 57.0, end: 63.2, layer: "main" },
  { id: "m9", text: "Slow the world to a heartbeat",        start: 64.0, end: 69.6, layer: "main" },
];

const BACKING_CLIPS = [
  { id: "b1", text: "ooh —",         start: 14.0, end: 17.0, layer: "backing" },
  { id: "b2", text: "(whisper) hush", start: 28.0, end: 32.0, layer: "backing" },
  { id: "b3", text: "ooh ooh —",     start: 50.0, end: 56.0, layer: "backing" },
  { id: "b4", text: "(echo) hours",  start: 65.0, end: 69.0, layer: "backing" },
];

const FX_CLIPS = [
  { id: "f1", text: "▲ INTRO",   start: 8.0,  end: 12.0, layer: "fx" },
  { id: "f2", text: "★ DROP",    start: 50.0, end: 51.2, layer: "fx" },
  { id: "f3", text: "( bridge )", start: 64.0, end: 67.0, layer: "fx" },
];

const ALL_CLIPS = [...MAIN_CLIPS, ...BACKING_CLIPS, ...FX_CLIPS];

// ============================================================
// Animation / FX presets — meaningful for lyrics, not random
// ============================================================

const ANIMATION_PRESETS = [
  { id: "fade",      label: "Fade",       group: "transition", thumbClass: "fade",     meta: "320ms · ease-out",  desc: "Soft entrance — default for most lyrics." },
  { id: "slide-up",  label: "Slide up",   group: "transition", thumbClass: "slide",    meta: "360ms · ease-out",  desc: "Energetic lift, good for choruses." },
  { id: "scale-in",  label: "Scale in",   group: "transition", thumbClass: "scale",    meta: "320ms · spring",    desc: "Punchy emphasis, single words." },
  { id: "blur-in",   label: "Blur in",    group: "transition", thumbClass: "blur",     meta: "480ms · ease-out",  desc: "Dreamy entries, slow songs." },
  { id: "glow-pop",  label: "Glow pop",   group: "transition", thumbClass: "glow",     meta: "260ms · pulse",     desc: "Hook reveals, drops." },
  { id: "glitch-in", label: "Glitch in",  group: "transition", thumbClass: "glitch",   meta: "260ms · steps",     desc: "Aggressive / electronic." },
];

const ACTIVE_PRESETS = [
  { id: "none",      label: "None",       thumbClass: "fade", meta: "Static" },
  { id: "breathing", label: "Breathing",  thumbClass: "breathing", meta: "Subtle scale" },
  { id: "wave",      label: "Wave",       thumbClass: "wave", meta: "Per-character" },
  { id: "flicker",   label: "Flicker",    thumbClass: "flicker", meta: "Random opacity" },
  { id: "glow-pulse",label: "Glow pulse", thumbClass: "glow", meta: "Halo pulse" },
];

const FX_PRESETS = [
  { id: "none",      label: "None",      thumbClass: "fade",    meta: "—" },
  { id: "soft-bloom",label: "Soft bloom",thumbClass: "bloom",   meta: "Halo wash" },
  { id: "prism",     label: "Prism / chromatic", thumbClass: "prism", meta: "RGB shift" },
  { id: "shimmer",   label: "Liquid shimmer",    thumbClass: "shimmer", meta: "Sweep highlight" },
  { id: "haze",      label: "Heat haze", thumbClass: "haze",    meta: "Soft warp" },
  { id: "glitch",    label: "Glitch",    thumbClass: "glitch",  meta: "Digital break" },
];

// ============================================================
// Pseudo-deterministic waveform peaks
// ============================================================

function hash(seed) {
  let h = seed | 0;
  return () => {
    h = (h * 1664525 + 1013904223) | 0;
    return ((h >>> 0) % 10000) / 10000;
  };
}

function buildWaveformPeaks(seed, count, base) {
  const rng = hash(seed);
  const peaks = new Array(count).fill(0).map((_, i) => {
    // Carrier envelope — verse/chorus dynamics
    const phase = i / count;
    const env =
      0.35 +
      Math.sin(phase * Math.PI * 6) * 0.18 +
      Math.sin(phase * Math.PI * 1.3 + 0.4) * 0.22 +
      Math.cos(phase * Math.PI * 13) * 0.08;
    const noise = (rng() - 0.5) * 0.7;
    return Math.max(0.04, Math.min(1, base * (env + noise * 0.6)));
  });
  return peaks;
}

const MASTER_PEAKS = buildWaveformPeaks(1024, 720, 0.85);
const VOCALS_PEAKS = buildWaveformPeaks(7331, 720, 0.6);

window.LyrixaData = {
  DEMO_TRACK,
  DEMO_LAYERS,
  ALL_CLIPS,
  MAIN_CLIPS,
  BACKING_CLIPS,
  FX_CLIPS,
  ANIMATION_PRESETS,
  ACTIVE_PRESETS,
  FX_PRESETS,
  MASTER_PEAKS,
  VOCALS_PEAKS,
};
