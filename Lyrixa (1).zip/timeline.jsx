/* global React, Icon, LyrixaData */
const { useRef, useEffect, useMemo, useState: useStateTL } = React;
const { MASTER_PEAKS, VOCALS_PEAKS } = LyrixaData;

// ============================================================
// Waveform — SVG canvas, fed by pre-baked peaks
// ============================================================

function Waveform({ peaks, color, accent = "active", durationSec, pxPerSec, scrollLeft = 0, viewportWidth }) {
  // Slice peaks to viewport for perf
  const totalWidth = durationSec * pxPerSec;
  const peakWidth = totalWidth / peaks.length;
  const startIdx = Math.max(0, Math.floor(scrollLeft / peakWidth) - 4);
  const endIdx = Math.min(peaks.length, Math.ceil((scrollLeft + viewportWidth) / peakWidth) + 4);
  const slice = peaks.slice(startIdx, endIdx);
  const offsetPx = startIdx * peakWidth;

  return (
    <svg
      className="waveform-svg"
      preserveAspectRatio="none"
      viewBox={`0 0 ${slice.length * 2} 100`}
      style={{ left: offsetPx - scrollLeft, width: slice.length * peakWidth, color }}
    >
      <g>
        {slice.map((v, i) => {
          const h = v * 100;
          return (
            <rect
              key={i}
              x={i * 2}
              y={50 - h / 2}
              width={1.2}
              height={h}
              rx={0.5}
              fill="currentColor"
              opacity={accent === "muted" ? 0.4 : 0.85}
            />
          );
        })}
      </g>
    </svg>
  );
}

// ============================================================
// Track header (left-side row labels)
// ============================================================

function TrackHeader({ name, accentColor, sub, pos, locked, hidden, onTogglePos, onToggleLocked, onToggleHidden, height, type }) {
  return (
    <div className="track-header" style={{ height }}>
      <span className="accent" style={{ background: accentColor }} />
      <div style={{ display: "flex", flexDirection: "column", flex: 1, minWidth: 0, padding: "0 0 0 6px", gap: 2 }}>
        <div className="th-name" style={{ display: "flex", alignItems: "center", gap: 6 }}>
          {type === "vocals" && <Icon name="mic" size={11} style={{ color: "var(--c-vocals)", flexShrink: 0 }} />}
          {type === "master" && <Icon name="waveform" size={11} style={{ color: "var(--c-master)", flexShrink: 0 }} />}
          <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{name}</span>
        </div>
        <div className="th-meta" style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{sub}</span>
          {pos && (
            <>
              <span style={{ opacity: 0.5 }}>·</span>
              <span style={{ color: "var(--fg-3)", flexShrink: 0 }}>{pos}</span>
            </>
          )}
        </div>
      </div>
      <div className="th-controls">
        <button title={hidden ? "Show" : "Hide"} className={hidden ? "muted-eye" : "on"} onClick={onToggleHidden}>
          <Icon name={hidden ? "eye-off" : "eye"} size={12} />
        </button>
        <button title={locked ? "Unlock" : "Lock"} className={locked ? "on" : ""} onClick={onToggleLocked}>
          <Icon name={locked ? "lock" : "lock-open"} size={12} />
        </button>
      </div>
    </div>
  );
}

// ============================================================
// Clip
// ============================================================

function Clip({ clip, color, pxPerSec, isSelected, isActive, onSelect, scrollLeft, layerType }) {
  const left = clip.start * pxPerSec - scrollLeft;
  const width = Math.max(40, (clip.end - clip.start) * pxPerSec);
  const fmtTime = (s) => {
    const m = Math.floor(s / 60);
    const sec = (s - m * 60).toFixed(2).padStart(5, "0");
    return `${m}:${sec}`;
  };

  // Layer-typed visual treatment
  const clipBg = `oklch(from ${color} l c h / 0.18)`;
  const clipBorder = `oklch(from ${color} l c h / 0.5)`;
  const clipBorderHover = `oklch(from ${color} l c h / 0.8)`;

  return (
    <div
      className={`clip ${isSelected ? "selected" : ""} ${isActive ? "active" : ""}`}
      style={{
        left,
        width,
        "--clip-bg": clipBg,
        "--clip-border": clipBorder,
        "--clip-border-hover": clipBorderHover,
      }}
      onClick={(e) => { e.stopPropagation(); onSelect(clip.id, e.shiftKey || e.metaKey || e.ctrlKey); }}
    >
      <div className="clip-text" style={{ color: layerType === "fx" ? color : "var(--fg-0)" }}>
        {clip.text}
      </div>
      <div className="clip-time">
        <span style={{ opacity: 0.75 }}>{fmtTime(clip.start)}</span>
        <span style={{ opacity: 0.4 }}>{" → "}</span>
        <span>{fmtTime(clip.end)}</span>
        <span style={{ marginLeft: 8, opacity: 0.5 }}>·</span>
        <span style={{ marginLeft: 8, opacity: 0.75 }}>{((clip.end - clip.start)).toFixed(2)}s</span>
      </div>
      <div className="resize-handle left" />
      <div className="resize-handle right" />
    </div>
  );
}

// ============================================================
// Ruler
// ============================================================

function Ruler({ durationSec, pxPerSec, scrollLeft, viewportWidth }) {
  const totalWidth = durationSec * pxPerSec;
  const minInterval = pxPerSec >= 100 ? 1 : pxPerSec >= 40 ? 2 : pxPerSec >= 20 ? 5 : 10;
  const ticks = [];
  const startSec = Math.max(0, Math.floor(scrollLeft / pxPerSec / minInterval) * minInterval);
  const endSec = Math.min(durationSec, Math.ceil((scrollLeft + viewportWidth) / pxPerSec));

  for (let s = startSec; s <= endSec; s += minInterval) {
    const x = s * pxPerSec - scrollLeft;
    const isMajor = s % (minInterval * 5) === 0;
    const isMinor = !isMajor && s % minInterval === 0;
    const m = Math.floor(s / 60);
    const sec = String(s - m * 60).padStart(2, "0");
    ticks.push(
      <div
        key={s}
        className={`ruler-tick ${isMajor ? "major" : "minor"}`}
        style={{ left: x }}
      >
        {isMajor ? `${m}:${sec}` : ""}
      </div>
    );
  }

  return <div className="ruler">{ticks}</div>;
}

// ============================================================
// Minimap
// ============================================================

function Minimap({ durationSec, scrollLeft, viewportWidth, pxPerSec, onScrubMap, currentTime, mapWidth }) {
  const totalWidth = durationSec * pxPerSec;
  const ratio = mapWidth / totalWidth;
  const viewportLeft = scrollLeft * ratio;
  const viewportW = Math.max(20, viewportWidth * ratio);
  const playheadX = currentTime * pxPerSec * ratio;

  return (
    <div className="minimap-track" onClick={onScrubMap}>
      <div className="minimap-wave" style={{ paddingInline: 4 }}>
        <svg
          preserveAspectRatio="none"
          viewBox={`0 0 ${MASTER_PEAKS.length} 100`}
          style={{ width: "100%", height: "70%", color: "var(--c-master)", opacity: 0.55 }}
        >
          {MASTER_PEAKS.map((v, i) => (
            <rect key={i} x={i} y={50 - v * 40} width={0.9} height={v * 80} fill="currentColor" />
          ))}
        </svg>
      </div>
      <div
        className="minimap-viewport"
        style={{ left: viewportLeft, width: viewportW }}
      />
      <div className="minimap-playhead" style={{ left: playheadX }} />
    </div>
  );
}

// ============================================================
// Main Timeline component
// ============================================================

const LANE_HEIGHTS = {
  master: 80,
  vocals: 64,
  lyrics: 56,
  backing: 56,
  fx: 56,
  annotation: 56,
};

function Timeline({
  layers,
  clipsByLayer,
  currentTime,
  durationSec,
  pxPerSec,
  setPxPerSec,
  scrollLeft,
  setScrollLeft,
  selectedClipIds,
  onSelectClip,
  onClearSelection,
  emptyMode, // null | 'no-audio' | 'no-lyrics' | 'loading'
  snapMode,
  setSnapMode,
  bandMode,
  setBandMode,
  wavesMode,
  setWavesMode,
  stemActive,
}) {
  const tracksRef = useRef(null);
  const [viewportWidth, setViewportWidth] = useStateTL(1000);
  const [mapWidth, setMapWidth] = useStateTL(800);
  const mapRef = useRef(null);

  useEffect(() => {
    function measure() {
      if (tracksRef.current) setViewportWidth(tracksRef.current.clientWidth);
      if (mapRef.current) setMapWidth(mapRef.current.clientWidth);
    }
    measure();
    const ro = new ResizeObserver(measure);
    if (tracksRef.current) ro.observe(tracksRef.current);
    if (mapRef.current) ro.observe(mapRef.current);
    return () => ro.disconnect();
  }, []);

  // Horizontal scrollwheel pan
  function handleWheel(e) {
    if (e.ctrlKey || e.metaKey) {
      // Zoom under cursor
      e.preventDefault();
      const rect = tracksRef.current.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const secAtCursor = (scrollLeft + x) / pxPerSec;
      const next = Math.max(8, Math.min(400, pxPerSec * (1 - e.deltaY * 0.002)));
      const nextScroll = Math.max(0, secAtCursor * next - x);
      setPxPerSec(next);
      setScrollLeft(nextScroll);
    } else {
      const delta = Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY;
      const max = Math.max(0, durationSec * pxPerSec - viewportWidth);
      setScrollLeft(Math.min(max, Math.max(0, scrollLeft + delta)));
    }
  }

  function scrubMap(e) {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const ratio = x / rect.width;
    const target = ratio * durationSec * pxPerSec - viewportWidth / 2;
    const max = Math.max(0, durationSec * pxPerSec - viewportWidth);
    setScrollLeft(Math.min(max, Math.max(0, target)));
  }

  const playheadX = currentTime * pxPerSec - scrollLeft;

  // Render lane rows in order: master, vocals (if active), then user layers
  const allLanes = [
    { id: "master", type: "master", name: "Master Track", sub: "Stereo · 44.1kHz", color: "var(--c-master)", height: LANE_HEIGHTS.master, peaks: MASTER_PEAKS, peakColor: "var(--c-master)", clips: [] },
    ...(stemActive ? [{ id: "vocals", type: "vocals", name: "Vocals (stem)", sub: "36 segments detected", color: "var(--c-vocals)", height: LANE_HEIGHTS.vocals, peaks: VOCALS_PEAKS, peakColor: "var(--c-vocals)", clips: [] }] : []),
    ...layers.filter(l => l.visible).map(l => ({
      id: l.id, type: l.type, name: l.name, sub: `${l.clipCount} clips`, color: l.color, height: LANE_HEIGHTS[l.type] || 56, peaks: null, peakColor: null, clips: clipsByLayer[l.id] || [], pos: l.pos, locked: l.locked,
    })),
  ];

  return (
    <>
      {/* Stage Toolbar */}
      <div className="stage-toolbar">
        <div className="tool-group">
          <button className="tool-btn" title="Selection (V)">
            <Icon name="drag" size={13} />
          </button>
          <button className="tool-btn active" title="Edit clip (E)">
            <Icon name="type" size={13} />
            Edit
          </button>
          <button className="tool-btn" title="Cut (C)">
            <Icon name="scissors" size={13} />
            Cut
          </button>
        </div>

        <div className="tool-group">
          <button className="tool-btn" onClick={() => setScrollLeft(Math.max(0, currentTime * pxPerSec - viewportWidth / 2))} title="Fit playhead">
            Fit playhead
          </button>
          <button className="tool-btn" onClick={() => { setPxPerSec(viewportWidth / durationSec); setScrollLeft(0); }} title="Fit song">
            Fit song
          </button>
        </div>

        <div className="tool-group" title="Zoom">
          <button className="tool-btn icon-only" onClick={() => setPxPerSec(Math.max(8, pxPerSec - 8))}><Icon name="minus" size={12} /></button>
          <span className="zoom-readout"><span className="num">{Math.round(pxPerSec)}</span>&nbsp;px/s</span>
          <button className="tool-btn icon-only" onClick={() => setPxPerSec(Math.min(400, pxPerSec + 8))}><Icon name="plus" size={12} /></button>
        </div>

        <div className="tool-group">
          <button className={`tool-btn ${snapMode === "off" ? "active" : ""}`} onClick={() => setSnapMode("off")}>Off</button>
          <button className={`tool-btn ${snapMode === "frame" ? "active" : ""}`} onClick={() => setSnapMode("frame")}>
            <Icon name="magnet" size={11} /> Frame
          </button>
          <button className={`tool-btn ${snapMode === "beat" ? "active" : ""}`} onClick={() => setSnapMode("beat")}>
            <Icon name="magnet" size={11} /> Beat
          </button>
          <button className={`tool-btn ${snapMode === "syllable" ? "active" : ""}`} onClick={() => setSnapMode("syllable")}>
            <Icon name="magnet" size={11} /> Syllable
          </button>
        </div>

        <div style={{ flex: 1 }} />

        <div className="tool-group">
          <span className="zoom-readout" style={{ paddingLeft: 8, color: "var(--fg-3)" }}>Band</span>
          <button className={`tool-btn ${bandMode === "auto" ? "active" : ""}`} onClick={() => setBandMode("auto")}>Auto</button>
          <button className={`tool-btn ${bandMode === "vocals" ? "active" : ""}`} onClick={() => setBandMode("vocals")}>Vocals</button>
          <button className={`tool-btn ${bandMode === "bass" ? "active" : ""}`} onClick={() => setBandMode("bass")}>Bass</button>
        </div>

        <div className="tool-group">
          <span className="zoom-readout" style={{ paddingLeft: 8, color: "var(--fg-3)" }}>Waves</span>
          <button className={`tool-btn ${wavesMode === "both" ? "active" : ""}`} onClick={() => setWavesMode("both")}>Both</button>
          <button className={`tool-btn ${wavesMode === "master" ? "active" : ""}`} onClick={() => setWavesMode("master")}>Master</button>
          <button className={`tool-btn ${wavesMode === "vocals" ? "active" : ""}`} onClick={() => setWavesMode("vocals")}>Vocals</button>
        </div>
      </div>

      {/* Minimap */}
      <div className="minimap" ref={mapRef}>
        <Minimap
          durationSec={durationSec}
          scrollLeft={scrollLeft}
          viewportWidth={viewportWidth}
          pxPerSec={pxPerSec}
          mapWidth={mapWidth}
          onScrubMap={scrubMap}
          currentTime={currentTime}
        />
      </div>

      {/* Main timeline grid */}
      <div className="timeline">
        <div className="ruler-pad">Time</div>
        <Ruler
          durationSec={durationSec}
          pxPerSec={pxPerSec}
          scrollLeft={scrollLeft}
          viewportWidth={viewportWidth}
        />

        {/* Track headers (left) */}
        <div className="track-headers">
          {allLanes.map(lane => (
            <TrackHeader
              key={lane.id}
              name={lane.name}
              sub={lane.sub}
              accentColor={lane.color}
              height={lane.height}
              type={lane.type}
              pos={lane.pos}
              locked={lane.locked}
              hidden={false}
            />
          ))}
        </div>

        {/* Lanes (right) */}
        <div className="tracks" ref={tracksRef} onWheel={handleWheel} onClick={onClearSelection}>
          <div className="tracks-inner">
            {allLanes.map(lane => (
              <div
                key={lane.id}
                className={`lane ${lane.type === "master" ? "master" : ""} ${lane.type === "vocals" ? "vocals" : ""}`}
                style={{ height: lane.height }}
              >
                <div className="lane-grid" style={{ backgroundSize: `${pxPerSec}px 100%` }} />

                {lane.peaks && (wavesMode === "both" || wavesMode === lane.type) && (
                  <Waveform
                    peaks={lane.peaks}
                    color={lane.peakColor}
                    accent={wavesMode === lane.type ? "active" : "muted"}
                    durationSec={durationSec}
                    pxPerSec={pxPerSec}
                    scrollLeft={scrollLeft}
                    viewportWidth={viewportWidth}
                  />
                )}

                {/* Clips */}
                {lane.clips.map(clip => {
                  const isActive = currentTime >= clip.start && currentTime <= clip.end;
                  return (
                    <Clip
                      key={clip.id}
                      clip={clip}
                      color={lane.color}
                      pxPerSec={pxPerSec}
                      isSelected={selectedClipIds.includes(clip.id)}
                      isActive={isActive}
                      onSelect={onSelectClip}
                      scrollLeft={scrollLeft}
                      layerType={lane.type}
                    />
                  );
                })}
              </div>
            ))}
          </div>

          {/* Playhead */}
          {playheadX >= 0 && playheadX <= viewportWidth && (
            <div className="playhead" style={{ left: playheadX }} />
          )}

          {/* Empty state overlays */}
          {emptyMode === "no-audio" && <EmptyAudio />}
          {emptyMode === "no-lyrics" && <EmptyLyrics />}
          {emptyMode === "loading" && <LoadingState />}
        </div>
      </div>
    </>
  );
}

// ============================================================
// Empty states
// ============================================================

function EmptyAudio() {
  return (
    <div className="state-card">
      <div className="state-content">
        <div className="state-icon"><Icon name="headphones" size={26} /></div>
        <div className="state-title">Drop in a master track to start</div>
        <div className="state-desc">
          Lyrixa works clip-first. Add an audio file and we'll bake a waveform, detect vocal segments, and prime the timeline so you can drop lyrics straight onto the beat.
        </div>
        <div className="state-actions">
          <button className="btn-primary">
            <Icon name="upload" size={14} />
            Upload audio
          </button>
          <button className="btn-ghost">
            <Icon name="file-music" size={14} />
            Recent projects
          </button>
        </div>
        <div className="label-eyebrow" style={{ marginTop: 4 }}>Supports WAV, MP3, FLAC, OGG · Max 200&nbsp;MB</div>
      </div>
    </div>
  );
}

function EmptyLyrics() {
  return (
    <div className="state-card" style={{ background: "transparent" }}>
      <div className="state-content">
        <div className="state-icon"><Icon name="type" size={26} /></div>
        <div className="state-title">Audio loaded. Now bring the words in.</div>
        <div className="state-desc">
          Paste lyrics from your DAW, drag in an LRC file, or let Lyrixa transcribe directly from the vocals stem. You can refine timing after — Lyrixa never locks you to its first guess.
        </div>
        <div className="state-actions">
          <button className="btn-primary">
            <Icon name="wand" size={14} />
            Transcribe from vocals
          </button>
          <button className="btn-ghost">
            <Icon name="type" size={14} />
            Paste lyrics
          </button>
          <button className="btn-ghost">
            <Icon name="upload" size={14} />
            Import LRC
          </button>
        </div>
      </div>
    </div>
  );
}

function LoadingState() {
  return (
    <div className="state-card">
      <div className="state-content">
        <div className="state-icon">
          <Icon name="loader" size={26} style={{ animation: "spin 1.2s linear infinite" }} />
          <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        </div>
        <div className="state-title">Analyzing vocals…</div>
        <div className="state-desc">
          Detecting segments, syllable timing, and onset peaks. This usually takes ~30s for a 3 minute track. You can keep editing other layers in the meantime.
        </div>
        <div style={{ width: 260, height: 6, background: "var(--bg-2)", borderRadius: 999, overflow: "hidden", marginTop: 4 }}>
          <div style={{ width: "62%", height: "100%", background: "var(--accent)", borderRadius: 999, transition: "width 0.4s" }} />
        </div>
        <div className="mono" style={{ color: "var(--fg-3)", fontSize: 11 }}>62% · 18s remaining</div>
      </div>
    </div>
  );
}

window.Timeline = Timeline;
