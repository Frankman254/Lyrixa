/* global React, Icon, LyrixaData */
const { useState: useStatePV, useRef: useRefPV, useEffect: useEffectPV } = React;

function FloatingPreview({
  currentTime,
  activeClip,
  fillType,
  previewMode,         // 'floating' | 'overlay' | 'hidden'
  setPreviewMode,
  bgMode,              // 'checker' | 'solid' | 'transparent'
  setBgMode,
  initial,
}) {
  const [pos, setPos] = useStatePV(initial?.pos || { x: 480, y: 320 });
  const [size, setSize] = useStatePV(initial?.size || { w: 520, h: 320 });
  const [minimized, setMinimized] = useStatePV(false);

  function startDrag(e) {
    e.preventDefault();
    const startX = e.clientX, startY = e.clientY;
    const sx = pos.x, sy = pos.y;
    const onMove = (ev) => setPos({ x: sx + ev.clientX - startX, y: sy + ev.clientY - startY });
    const onUp = () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
  }

  function startResize(e) {
    e.preventDefault();
    e.stopPropagation();
    const startX = e.clientX, startY = e.clientY;
    const sw = size.w, sh = size.h;
    const onMove = (ev) => setSize({ w: Math.max(280, sw + ev.clientX - startX), h: Math.max(180, sh + ev.clientY - startY) });
    const onUp = () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
  }

  if (previewMode === "hidden") return null;

  // Overlay mode: full-screen transparent overlay on top of editor
  if (previewMode === "overlay") {
    return (
      <div style={{
        position: "fixed",
        inset: 0,
        zIndex: 1000,
        background: "rgba(0,0,0,0.78)",
        backdropFilter: "blur(2px)",
        display: "grid",
        placeItems: "center",
        pointerEvents: "auto",
      }}>
        <div style={{ position: "absolute", top: 20, right: 20, display: "flex", gap: 8 }}>
          <button className="btn-ghost" onClick={() => setPreviewMode("floating")}>
            <Icon name="minimize" size={14} />
            Exit overlay
          </button>
        </div>
        <div style={{
          position: "absolute", top: 20, left: 20,
          display: "inline-flex", alignItems: "center", gap: 8,
          padding: "6px 12px",
          background: "rgba(0,0,0,0.6)",
          border: "1px solid var(--border)",
          borderRadius: "var(--r-3)",
          fontFamily: "var(--font-mono)",
          fontSize: 11, letterSpacing: "0.12em", textTransform: "uppercase",
          color: "var(--fg-1)"
        }}>
          <span style={{ width: 7, height: 7, borderRadius: 999, background: "var(--live)", boxShadow: "0 0 10px var(--live)" }} />
          Overlay preview · live
        </div>
        <PreviewLyric clip={activeClip} fillType={fillType} big />
      </div>
    );
  }

  // Floating window mode
  const headerOnly = minimized;

  return (
    <div
      className="preview-window"
      style={{
        left: pos.x,
        top: pos.y,
        width: headerOnly ? 280 : size.w,
        height: headerOnly ? 32 : size.h,
      }}
    >
      <div className="preview-header" onMouseDown={startDrag}>
        <span className="dot" />
        <span>Live Preview</span>
        <span style={{ color: "var(--fg-3)", marginLeft: 4 }}>·</span>
        <span className="mono" style={{ color: "var(--fg-3)", textTransform: "none", letterSpacing: 0, fontSize: 11 }}>
          {Math.floor(currentTime/60)}:{(currentTime%60).toFixed(2).padStart(5,'0')}
        </span>
        <span className="spacer" />
        <button title="Minimize" onClick={() => setMinimized(!minimized)}>
          <Icon name={minimized ? "chev-up" : "chev-down"} size={11} />
        </button>
        <button title="Full overlay" onClick={() => setPreviewMode("overlay")}>
          <Icon name="overlay" size={11} />
        </button>
        <button title="Close" onClick={() => setPreviewMode("hidden")}>
          <Icon name="x" size={11} />
        </button>
      </div>

      {!minimized && (
        <>
          <div className={`preview-stage ${bgMode === "solid" ? "solid" : ""}`}>
            <PreviewLyric clip={activeClip} fillType={fillType} />
          </div>

          <div className="preview-toolbar">
            <div className="mode-seg">
              <button className={bgMode === "checker" ? "active" : ""} onClick={() => setBgMode("checker")}>Checker</button>
              <button className={bgMode === "solid" ? "active" : ""} onClick={() => setBgMode("solid")}>Solid</button>
            </div>
            <span style={{ flex: 1 }} />
            <div className="mode-seg">
              <button title="16:9" className="active">16:9</button>
              <button title="9:16">9:16</button>
              <button title="1:1">1:1</button>
            </div>
            <button className="tool-btn icon-only" title="Pop into overlay" onClick={() => setPreviewMode("overlay")} style={{ width: 22, height: 22 }}>
              <Icon name="expand" size={11} />
            </button>
          </div>
          <div className="preview-resize" onMouseDown={startResize} />
        </>
      )}
    </div>
  );
}

function PreviewLyric({ clip, fillType, big }) {
  const text = clip?.text || "Velvet hours, velvet hours";

  let fillStyle = {};
  if (fillType === "gradient") {
    fillStyle = {
      background: "linear-gradient(110deg, #ffffff 0%, #80eaff 45%, #ff6bd5 100%)",
      WebkitBackgroundClip: "text",
      backgroundClip: "text",
      WebkitTextFillColor: "transparent",
    };
  } else if (fillType === "texture") {
    fillStyle = {
      background: "url('data:image/svg+xml;utf8,<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 200 200\"><defs><radialGradient id=\"g\" cx=\"30%25\" cy=\"30%25\"><stop offset=\"0%25\" stop-color=\"%23f3c886\"/><stop offset=\"50%25\" stop-color=\"%23d97757\"/><stop offset=\"100%25\" stop-color=\"%237fc69a\"/></radialGradient></defs><rect width=\"200\" height=\"200\" fill=\"url(%23g)\"/><circle cx=\"50\" cy=\"60\" r=\"20\" fill=\"%23ffe0a8\" opacity=\"0.7\"/><circle cx=\"150\" cy=\"140\" r=\"30\" fill=\"%23a8d8b5\" opacity=\"0.5\"/></svg>') center/cover",
      WebkitBackgroundClip: "text",
      backgroundClip: "text",
      WebkitTextFillColor: "transparent",
      filter: "saturate(1.18) brightness(1.08) contrast(1.22)",
    };
  }

  return (
    <div
      className="preview-lyric"
      style={{
        fontSize: big ? 84 : 38,
        ...fillStyle,
        animation: "preview-pulse 4s ease-in-out infinite",
      }}
    >
      <style>{`@keyframes preview-pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.02); } }`}</style>
      {text}
    </div>
  );
}

window.FloatingPreview = FloatingPreview;
